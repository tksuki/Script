from dec4 import *

def terminal(ast):
    if not ast: return False
    k = ast[-1]
    return k[0] in ('brk', 'cont', 'goto') or (k[0] == 's' and k[1].startswith('return'))

def E_on_use(self, root): self.use_path[root].append(tuple(self.scope))
Emitter.on_use = E_on_use

def E_func(self, e):
    pid, caps = e[1], e[2]
    ups = []
    for c in caps:
        if c[0] == 'REG': self.on_use(c[1][1]); ups.append(self.webname(c[1][1]))
        else: ups.append(self.up(c[1]))
    if not self.final: return 'function() --[[ P%d ]] end' % pid
    key = (pid, tuple(ups))
    em = Emitter(self.protos, pid, ups, self.depth + 1)
    return em.render_function()
Emitter.func = E_func

def E_defweb(self, s, r):
    root = self.B.def_web[(s.id, r)]
    self.def_path.setdefault(root, tuple(self.scope))
    return root

def E_block_stmts(self, L):
    out = []; nodes = self.nodes[L]; i = 0
    while i < len(nodes):
        s = nodes[i]; i += 1
        k = s.k
        if k in ('cond', 'forprep', 'forloop', 'tforprep', 'tforloop', 'params') or s.dead:
            if k == 'params':
                for r in s.dsts: self.defweb(s, r)
            continue
        if k == 'assign':
            root = self.defweb(s, s.dsts[0]); w = self.webs[root]
            e = s.e
            if e == ('TABLE',) and root not in self.hoist and len(w.defs) == 1:
                items = []; j = i
                while j < len(nodes):
                    n = nodes[j]
                    if n.k == 'store' and n.t[0] == 'IDX' and n.t[1] == ('V', root) and not self.refs(n.t[2], root) and not self.refs(n.v, root):
                        kk = n.t[2]
                        if kk[0] == 'K' and isinstance(kk[1], tuple) and kk[1][0] == 'S' and isident(kk[1][1]): items.append((kk[1][1].decode('ascii') + ' = ', n.v))
                        else: items.append(('[%s] = ' % self.ex(kk), n.v))
                        j += 1
                    elif n.k == 'setlist' and n.t == ('V', root) and not any(self.refs(v, root) for v in n.vals):
                        off = n.extra
                        for ii, v in enumerate(n.vals):
                            items.append(('' if off == 0 else '[%d] = ' % (off + ii + 1), v))
                        j += 1
                    else: break
                if items:
                    i = j
                    body = ', '.join(p + self.ex(v) for p, v in items)
                    out.append(('s', self.decl(root, '{' + body + '}'))); continue
            out.append(('s', self.decl(root, self.ex(e)))); continue
        if k == 'multiassign':
            roots = [self.defweb(s, r) for r in s.dsts]
            live = [self.webs[r].nuses > 0 or len(self.webs[r].defs) > 1 for r in roots]
            if s.e == ('K', None):
                names = [self.webname(r) for r, l in zip(roots, live) if l]
                if not names: continue
                hoisted = all(r in self.hoist for r, l in zip(roots, live) if l)
                if hoisted: out.append(('s', ', '.join(names) + ' = ' + ', '.join(['nil'] * len(names))))
                else:
                    for r, l in zip(roots, live):
                        if l: self.declared.add(r)
                    out.append(('s', 'local ' + ', '.join(names)))
                continue
            names = [self.webname(r) if l else '_' for r, l in zip(roots, live)]
            pre = '' if all(r in self.hoist for r in roots) else 'local '
            for r in roots: self.declared.add(r)
            out.append(('s', pre + ', '.join(names) + ' = ' + self.ex(s.e))); continue
        if k == 'callstmt':
            t = self.ex(s.e)
            if s.e[0] != 'CALL': t = 'local _ = ' + t
            out.append(('s', t)); continue
        if k == 'store':
            tg = s.t
            if tg[0] == 'IDX': lhs = self.idx(tg)
            else: lhs = self.ex(tg)
            out.append(('s', '%s = %s' % (lhs, self.ex(s.v)))); continue
        if k == 'setlist':
            out.append(('s', 'table.move({%s}, 1, %d, %d, %s)' % (', '.join(self.ex(v) for v in s.vals), len(s.vals), s.extra + 1, self.ex(s.t)))); continue
        if k == 'ret':
            out.append(('s', 'return' + (' ' + ', '.join(self.ex(v) for v in s.vals) if s.vals else ''))); continue
        if k == 'bad':
            out.append(('s', '-- <undecodable instruction pc=%s>' % s.pc)); continue
    return out
Emitter.block_stmts = E_block_stmts
Emitter.defweb = E_defweb

def E_refs(self, e, root):
    if e == ('V', root): return True
    if isinstance(e, tuple):
        return any(self.refs(x, root) for x in e if isinstance(x, (tuple, list)) ) if not (e and e[0] == 'V') else False
    if isinstance(e, list): return any(self.refs(x, root) for x in e)
    return False
Emitter.refs = E_refs

def E_decl(self, root, text):
    name = self.webname(root)
    if root in self.hoist or root in self.declared or len(self.webs[root].defs) > 1 or self.webs[root].undef:
        if root in self.hoist or re.match(r'^[a-z]\d*a\d+$', name): return '%s = %s' % (name, text)
        if root in self.declared: return '%s = %s' % (name, text)
        self.declared.add(root); return 'local %s = %s' % (name, text)
    self.declared.add(root); return 'local %s = %s' % (name, text)
Emitter.decl = E_decl

# ------------------------------------------------------------------ structuring
def E_push(self): self.sc += 1; self.scope.append(self.sc)
def E_pop(self): self.scope.pop()
Emitter.push = E_push; Emitter.pop = E_pop

def E_gen(self, L, stops, ctx, first=False):
    out = []
    while True:
        if L is None: return out
        if not first:
            if ctx and L == ctx['cont']: out.append(('cont',)); return out
            if ctx and L == ctx['break']: out.append(('brk',)); return out
            if L in stops: return out
        first = False
        if L in self.visited:
            if L not in self.loops and hasattr(self, 'small_terminal') and self.small_terminal(L):
                cur = L
                while True:
                    out += self.block_stmts(cur)
                    bb = self.blocks[cur]
                    if bb.kind == 'ret': return out
                    cur = bb.succ[0]
            self.gotos.add(L); out.append(('goto', L)); return out
        if L in self.loops and L not in self.active:
            L = self.emit_loop(L, out, ctx); 
            if L == 'END': return out
            continue
        self.visited.add(L)
        if L in self.labels: out.append(('label', L))
        out += self.block_stmts(L)
        b = self.blocks[L]; k = b.kind
        if k == 'ret': return out
        if k == 'goto': L = b.succ[0]; continue
        if k == 'cjump':
            taken, fall = b.succ
            cs = [n for n in self.nodes[L] if n.k == 'cond']
            jc = cs[-1].e
            M = self.ipdom.get(L)
            sub = stops | ({M} if M is not None else set())
            self.push(); thn = self.gen(fall, sub, ctx); self.pop()
            self.push(); els = self.gen(taken, sub, ctx); self.pop()
            out += self.make_if(jc, thn, els)
            if M is None: return out
            if (ctx and (M == ctx['cont'] or M == ctx['break'])) or M in stops: return out
            L = M; continue
        if k in ('forprep', 'tforprep'):
            F0 = b.succ[0] if b.succ else None
            if F0 is None or F0 not in self.blocks or self.blocks[F0].kind not in ('forloop', 'tforloop'):
                out.append(('s', '-- <malformed for-loop>')); return out
            L = self.emit_for(L, out)
            if L == 'END': return out
            continue
        if k in ('forloop', 'tforloop'):
            self.gotos.add(L); out.append(('goto', L)); return out
        return out
Emitter.gen = E_gen

def E_make_if(self, jc, thn, els):
    neg = self.negate(jc)
    ct, cj = self.ex(neg), self.ex(jc)
    if not thn and not els: return []
    if not thn: return [('if', cj, els, None)]
    if not els: return [('if', ct, thn, None)]
    if terminal(thn): return [('if', ct, thn, None)] + els
    if terminal(els): return [('if', cj, els, None)] + thn
    return [('if', ct, thn, els)]
Emitter.make_if = E_make_if

def simple(t): return re.match(r'^[\w.:\[\]\"\']+(\([^()]*\))?$', t) is not None
def andjoin(a, b):
    if a == 'true': return b
    return '%s and %s' % (a if simple(a) or ' or ' not in a else '(' + a + ')', b if simple(b) or ' or ' not in b else '(' + b + ')')
def clean_while(wc, body):
    while len(body) == 2 and body[1][0] == 'brk' and body[0][0] == 'if' and body[0][3] is None and body[0][2] and body[0][2][-1][0] == 'cont':
        wc = andjoin(wc, body[0][1]); body = body[0][2][:-1]
    return wc, body
def strip_tail(body):
    while body and body[-1][0] == 'cont': body.pop()
    return body

def E_emit_for(self, P, out):
    b = self.blocks[P]; F = b.succ[0]; fb = self.blocks[F]
    prep = [n for n in self.nodes[P] if n.k in ('forprep', 'tforprep')][-1]
    out += self.block_stmts(P); self.visited.add(P)
    body0, exit_ = fb.succ[0], (fb.succ[1] if len(fb.succ) > 1 else None)
    self.visited.add(F)
    lp = [n for n in self.nodes[F] if n.k in ('forloop', 'tforloop')][0]
    if prep.k == 'forprep':
        root = self.defweb(lp, lp.dsts[0]); name = self.webname(root)
        self.declared.add(root)
        v = prep.vals
        step = '' if v[2] == ('K', 1) else ', ' + self.ex(v[2])
        header = 'for %s = %s, %s%s do' % (name, self.ex(v[0]), self.ex(v[1]), step)
    else:
        rk = self.defweb(lp, lp.dsts[0]); rv = self.defweb(lp, lp.dsts[1])
        for r in (rk, rv): self.declared.add(r)
        nk = self.webname(rk)
        nv = self.webname(rv) if self.webs[rv].nuses > 0 else None
        vars_ = nk + (', ' + nv if nv else '')
        v = prep.vals
        # merge with a producing call: for k,v in pairs(x)
        header = 'for %s in %s do' % (vars_, ', '.join(self.ex(x) for x in v))
        if len(v) == 3 and v[1] == ('K', None) and v[2] == ('K', None): header = 'for %s in %s do' % (vars_, self.ex(v[0]))
    self.push()
    body = strip_tail(self.gen(body0, set(), {'cont': F, 'break': exit_}))
    self.pop()
    out.append(('for', header, body))
    return exit_ if exit_ is not None else 'END'
Emitter.emit_for = E_emit_for

def E_emit_loop(self, H, out, ctx):
    body = self.loops[H]; blocks = self.blocks
    exits = []
    for x in body:
        for s in self.succ[x]:
            if s not in body and s not in exits: exits.append(s)
    self.active.add(H)
    hb = blocks[H]
    cs = [n for n in self.nodes[H] if n.k == 'cond']
    leftover = [n for n in self.block_stmts_peek(H)]
    if hb.kind == 'cjump' and len(hb.succ) == 2 and sum(1 for s in hb.succ if s in body) == 1 and not leftover:
        taken, fall = hb.succ
        jc = cs[-1].e
        self.visited.add(H)
        if taken in body: cond, inside, X = jc, taken, fall
        else: cond, inside, X = self.negate(jc), fall, taken
        self.push()
        bd = strip_tail(self.gen(inside, set(), {'cont': H, 'break': X}))
        self.pop()
        wc, bd = clean_while(self.ex(cond), bd)
        out.append(('while', wc, bd))
        return X if X is not None else 'END'
    # generic loop
    if not exits: X = None
    elif len(exits) == 1: X = exits[0]
    else:
        ip = self.ipdom.get(H)
        X = ip if ip in exits else sorted(exits)[0]
    self.push()
    bd = self.gen(H, set(), {'cont': H, 'break': X}, first=True)
    self.pop()
    bd = strip_tail(bd)
    # repeat-until pattern:  ... if c then <cont> else <brk>  -> if not c then break
    wc, bd = clean_while('true', bd)
    out.append(('while', wc, bd))
    return X if X is not None else 'END'
Emitter.emit_loop = E_emit_loop

def E_peek(self, L):
    return [n for n in self.nodes[L] if n.k not in ('cond', 'forprep', 'forloop', 'tforprep', 'tforloop', 'params') and not n.dead]
Emitter.block_stmts_peek = E_peek

# ------------------------------------------------------------------ rendering
def rend(ast, ind, out):
    pad = '  ' * ind
    for n in ast:
        k = n[0]
        if k == 's':
            txt = n[1]
            if txt.startswith('('): txt = ';' + txt
            out.append('\n'.join((pad + ln) for ln in txt.split('\n')))
        elif k == 'brk': out.append(pad + 'break')
        elif k == 'cont': out.append(pad + 'continue')
        elif k == 'goto': out.append(pad + 'goto L%s' % n[1])
        elif k == 'label': out.append(pad + '::L%s::' % n[1])
        elif k == 'if':
            out.append(pad + 'if %s then' % n[1]); rend(n[2], ind + 1, out)
            els = n[3]
            while els is not None:
                if len(els) == 1 and els[0][0] == 'if':
                    e = els[0]; out.append(pad + 'elseif %s then' % e[1]); rend(e[2], ind + 1, out); els = e[3]
                else:
                    out.append(pad + 'else'); rend(els, ind + 1, out); els = None
            out.append(pad + 'end')
        elif k == 'while':
            out.append(pad + 'while %s do' % n[1]); rend(n[2], ind + 1, out); out.append(pad + 'end')
        elif k == 'for':
            out.append(pad + n[1]); rend(n[2], ind + 1, out); out.append(pad + 'end')

def E_run(self, final):
    self.final = final
    self.visited = set(); self.active = set(); self.scope = []; self.sc = 0
    self.counter = 0
    for w in self.webs.values(): w.name = None
    self.def_path = {}; self.use_path = collections.defaultdict(list); self.declared = set()
    if not hasattr(self, 'hoist'): self.hoist = set()
    if not hasattr(self, 'labels'): self.labels = set()
    self.gotos = set()
    return self.gen(self.entry, set(), None)
Emitter.run = E_run

def E_render_function(self):
    self.hoist = set(); self.labels = set()
    self.run(False)
    # hoist computation
    params = set()
    for L in self.nodes:
        for s in self.nodes[L]:
            if s.k == 'params':
                for r in s.dsts: params.add(self.B.def_web[(s.id, r)])
    hoist = set()
    for root, w in self.webs.items():
        if root in params: continue
        if len(w.defs) == 0: continue
        if w.nuses == 0 and len(w.defs) == 1: continue
        if len(w.defs) > 1 or w.undef: hoist.add(root); continue
        dp = self.def_path.get(root)
        if dp is None: continue
        for up in self.use_path.get(root, []):
            if up[:len(dp)] != dp: hoist.add(root); break
    self.hoist = hoist; self.labels = set(self.gotos)
    ast = self.run(True)
    # header
    pstmt = None
    for L in self.nodes:
        for s in self.nodes[L]:
            if s.k == 'params': pstmt = s
    names = []; va = False
    if pstmt is not None:
        for r in pstmt.dsts: names.append(self.webname(self.B.def_web[(pstmt.id, r)]))
        va = bool(pstmt.extra)
    if va: names.append('...')
    lines = []
    if hoist:
        hn = sorted(self.webname(r) for r in hoist if self.webs[r].nuses > 0 or len(self.webs[r].defs) > 1)
        if hn: lines.append('local ' + ', '.join(hn))
    rend(ast, 0, lines)
    lines = '\n'.join(lines).split('\n')
    if self.depth == 0: return '\n'.join(lines)
    body = '\n'.join('  ' + l for l in lines)
    return 'function(%s)\n%s\nend' % (', '.join(names), body)
Emitter.render_function = E_render_function

if __name__ == '__main__':
    protos = load()
    pid = int(sys.argv[1])
    em = Emitter(protos, pid, [], depth=0)
    print(em.render_function())
