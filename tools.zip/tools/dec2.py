from dec import *

class Stmt:
    __slots__ = ('id','k','dsts','e','t','v','uses','pc','blk','vals','extra','alias','dead')
    def __init__(self, k, **kw):
        self.k = k; self.dsts = []; self.e = None; self.t = None; self.v = None; self.uses = []
        self.pc = None; self.blk = None; self.vals = None; self.extra = None; self.alias = None; self.dead = False
        for a, b in kw.items(): setattr(self, a, b)

class Builder:
    def __init__(self, f):
        self.f = f; self.sid = 0; self.uid = 0
    def newstmt(self, k, **kw):
        s = Stmt(k, **kw); s.id = self.sid; self.sid += 1; return s
    def rd(self, st, r):
        self.uid += 1; u = (self.uid, r); st.uses.append(u); return ('R', r, self.uid)
    def walk_uses(self, st, e):
        """convert ('R',r) leaves in a freshly built expression into use-tagged leaves, in eval order"""
        t = e[0]
        if t == 'R': return self.rd(st, e[1])
        if t in ('BIN',): return ('BIN', e[1], self.walk_uses(st, e[2]), self.walk_uses(st, e[3]))
        if t == 'UN': return ('UN', e[1], self.walk_uses(st, e[2]))
        if t == 'IDX': return ('IDX', self.walk_uses(st, e[1]), self.walk_uses(st, e[2]))
        if t == 'BXOR': return ('BXOR', self.walk_uses(st, e[1]), self.walk_uses(st, e[2]))
        return e

def build_stmts(f, b, B):
    """return list of Stmt for block b (terminator cond stored as stmt.k=='cond')"""
    out = []; opn = None
    def flush():
        nonlocal opn
        if opn is not None:
            s = B.newstmt('callstmt', e=opn[1]); s.uses = opn[2]; out.append(s); opn = None
    for pc in b.pcs:
        d = f.dec[pc]; k = d[0]
        if k == 'set':
            flush(); s = B.newstmt('assign', pc=pc); dst = d[1]; s.e = B.walk_uses(s, d[2]); s.dsts = [dst]
            if dst is None: continue
            out.append(s)
        elif k == 'store':
            flush(); s = B.newstmt('store', pc=pc)
            tgt = d[1]
            if tgt[0] == 'IDX': s.t = ('IDX', B.walk_uses(s, tgt[1]), B.walk_uses(s, tgt[2]))
            else: s.t = tgt
            s.v = B.walk_uses(s, d[2]); out.append(s)
        elif k == 'call':
            A, Bc, C = d[1], d[2], d[3]
            s = B.newstmt('call', pc=pc)
            fe = B.rd(s, A)
            args = []
            if Bc == 0:
                start = opn[0] if opn else A + 1
                for r in range(A + 1, start): args.append(B.rd(s, r))
                if opn:
                    args.append(opn[1]); s.uses = opn[2] + s.uses if False else s.uses
                    s.uses = s.uses + opn[2]; opn = None
            else:
                flush_needed = opn is not None
                if flush_needed: flush()
                for r in range(A + 1, A + Bc): args.append(B.rd(s, r))
            ce = ('CALL', fe, args)
            if C == 1: s.k = 'callstmt'; s.e = ce; out.append(s)
            elif C == 2: s.k = 'assign'; s.e = ce; s.dsts = [A]; out.append(s)
            elif C == 0:
                opn = (A, ce, s.uses)
            else: s.k = 'multiassign'; s.e = ce; s.dsts = list(range(A, A + C - 1)); out.append(s)
        elif k == 'self':
            flush(); A, Bq, key = d[1], d[2], d[3]
            s1 = B.newstmt('assign', pc=pc); obj = B.rd(s1, Bq); s1.e = ('SELFFN', obj, key); s1.dsts = [A]
            s2 = B.newstmt('assign', pc=pc); s2.e = ('SELFOBJ', obj); s2.dsts = [A + 1]; s2.alias = s1
            out.append(s1); out.append(s2)
        elif k == 'closure':
            flush(); A, pid = d[1], d[2]
            s = B.newstmt('assign', pc=pc); s.dsts = [A]
            caps = []
            if isinstance(pid, tuple) and pid[0] == 'P':
                for (idx, ty) in B.protos[pid[1]]['ups']:
                    if ty in (0, 1): caps.append(('REG', B.rd(s, idx)))
                    else: caps.append(('UPREF', idx))
                s.e = ('FUNC', pid[1], caps)
            else: s.e = ('K', None)
            out.append(s)
        elif k == 'loadnil':
            flush(); s = B.newstmt('multiassign', pc=pc); s.e = ('K', None); s.dsts = list(range(d[1], d[2] + 1)); out.append(s)
        elif k == 'params':
            flush(); s = B.newstmt('params', pc=pc); s.dsts = list(range(1, d[1] + 1)); s.extra = d[2]; out.append(s)
        elif k == 'vararg':
            flush(); opn = (d[1], ('VARARGS',), [])
        elif k == 'setlist':
            A, n, off = d[1], d[2], d[3]
            s = B.newstmt('setlist', pc=pc); tb = B.rd(s, A); items = []
            if n is None:
                start = opn[0] if opn else A + 1
                for r in range(A + 1, start): items.append(B.rd(s, r))
                if opn: items.append(opn[1]); s.uses = s.uses + opn[2]; opn = None
            else:
                flush()
                for r in range(A + 1, A + n + 1): items.append(B.rd(s, r))
            s.t = tb; s.vals = items; s.extra = off; out.append(s)
        elif k == 'tail':
            A, Bc = d[1], d[2]
            s = B.newstmt('ret', pc=pc)
            fe = B.rd(s, A); args = []
            if Bc == 0:
                start = opn[0] if opn else A + 1
                for r in range(A + 1, start): args.append(B.rd(s, r))
                if opn: args.append(opn[1]); s.uses = s.uses + opn[2]; opn = None
            else:
                flush()
                for r in range(A + 1, A + Bc): args.append(B.rd(s, r))
            s.vals = [('CALL', fe, args)]; out.append(s)
        elif k == 'ret':
            first, cnt = d[1], d[2]
            s = B.newstmt('ret', pc=pc); vals = []
            if cnt is None:
                start = opn[0] if opn else first + 1
                for r in range(first, start): vals.append(B.rd(s, r))
                if opn: vals.append(opn[1]); s.uses = s.uses + opn[2]; opn = None
            else:
                flush()
                for r in range(first, first + cnt): vals.append(B.rd(s, r))
            s.vals = vals; out.append(s)
        elif k == 'cjump':
            flush(); s = B.newstmt('cond', pc=pc); s.e = B.walk_uses(s, d[1]); out.append(s)
        elif k == 'forprep':
            flush(); s = B.newstmt('forprep', pc=pc); A = d[1]
            s.vals = [B.rd(s, A), B.rd(s, A + 1), B.rd(s, A + 2)]; s.extra = A; out.append(s)
        elif k == 'forloop':
            flush(); s = B.newstmt('forloop', pc=pc); s.extra = d[1]; s.dsts = [d[1] + 3]; out.append(s)
        elif k == 'tforprep':
            flush(); s = B.newstmt('tforprep', pc=pc); A = d[1]
            s.vals = [B.rd(s, A), B.rd(s, A + 1), B.rd(s, A + 2)]; s.extra = A; out.append(s)
        elif k == 'tforloop':
            flush(); s = B.newstmt('tforloop', pc=pc); s.extra = d[1]; s.dsts = [d[1] + 1, d[1] + 2]; out.append(s)
        elif k in ('bad', 'unknown'):
            flush(); s = B.newstmt('bad', pc=pc); out.append(s)
    flush()
    for s in out: s.blk = b.leader
    return out
