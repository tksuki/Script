import sys, re, collections
from patch import *
from patch2 import apply_patches2, collect_patches2
from patch3 import apply_patches3
sys.setrecursionlimit(20000)

# ------------------------------------------------------------------ preparation
def patch_writer_pcs(p):
    arrs = {}; w = set()
    for pc in sorted(p['ins']):
        ins = p['ins'][pc]; op = ins['op']
        if op == 92 and ins['G'] is not None: arrs[ins['G']] = 'g'
        elif op == 87 and ins['o'] is not None: arrs[ins['o']] = 'G'
        elif op == 142 and ins['G'] is not None: arrs[ins['G']] = 'o'
        elif op == 83 and ins['g'] is not None: arrs[ins['g']] = '_'
        elif op == 139 and ins['G'] is not None: arrs[ins['G']] = 'R'
        elif op == 41 and ins['g'] is not None: arrs[ins['g']] = 'H'
        elif op == 143 and ins['g'] in arrs: arrs.pop(ins['g'])
        elif op == 69 and ins['o'] in arrs and isinstance(ins['p'], int) and isinstance(ins['a'], (int, float)) and not isinstance(ins['a'], bool):
            w.add(pc)
    return w

class Func:
    pass

def prepare(p):
    q, wr, conf, unres, _vis = apply_patches3(p)
    f = Func(); f.id = p['id']; f.regs = p['regs']; f.ups = p['ups']; f.ins = q['ins']
    f.dec = {}
    decided = q.get('decided', {})
    for pc, ins in f.ins.items():
        f.dec[pc] = ('junk', 0) if pc in wr else safe_decode(ins)
        dd = decided.get(pc)
        if dd is not None and f.dec[pc][0] == 'cjump' and len(dd) == 1 and None not in dd:
            if True in dd: f.dec[pc] = ('jump', f.dec[pc][2])
            else: f.dec[pc] = ('nop',)
    return f

def resolve(f, pc):
    seen = set()
    while True:
        if pc not in f.dec: return None
        d = f.dec[pc]
        if d[0] in ('nop', 'junk'): pc += 1
        elif d[0] == 'jump': pc = d[1] + 1
        else: return pc
        if pc in seen: return None
        seen.add(pc)

def csucc(f, pc):
    try: return csucc0(f, pc)
    except TypeError: return 'ret', []

def csucc0(f, pc):
    """control successors of meaningful pc: returns (kind, [succ pcs])"""
    d = f.dec[pc]; k = d[0]
    if k in ('ret', 'tail'): return 'ret', []
    if k == 'cjump': return k, [resolve(f, d[2] + 1), resolve(f, pc + 1)]      # [taken, fallthrough]
    if k == 'forprep': return k, [resolve(f, d[2] + 1)]
    if k == 'tforprep': return k, [resolve(f, d[2] + 1)]
    if k == 'forloop': return k, [resolve(f, d[2] + 1), resolve(f, pc + 1)]    # [body, exit]
    if k == 'tforloop': return k, [resolve(f, d[2] + 1), resolve(f, pc + 1)]
    if k == 'bad': return 'ret', []
    return 'seq', [resolve(f, pc + 1)]

class Block:
    def __init__(self, leader): self.leader = leader; self.pcs = []; self.kind = None; self.succ = []; self.preds = []

def build_cfg(f):
    entry = resolve(f, 1)
    # reachable meaningful pcs
    seen = set(); st = [entry]; info = {}
    while st:
        pc = st.pop()
        if pc is None or pc in seen: continue
        seen.add(pc); k, ss = csucc(f, pc); info[pc] = (k, ss)
        for s in ss: st.append(s)
    preds = collections.Counter()
    for pc, (k, ss) in info.items():
        for s in ss:
            if s is not None: preds[s] += 1
    leaders = {entry}
    for pc, (k, ss) in info.items():
        if k != 'seq':
            for s in ss:
                if s is not None: leaders.add(s)
        else:
            s = ss[0]
            if s is not None and preds[s] != 1: leaders.add(s)
    blocks = {}
    for L in leaders:
        b = Block(L); pc = L
        while True:
            b.pcs.append(pc); k, ss = info[pc]
            if k == 'seq':
                s = ss[0]
                if s is None: b.kind = 'ret'; b.succ = []; break
                if s in leaders: b.kind = 'goto'; b.succ = [s]; break
                pc = s
            else:
                b.kind = k; b.succ = ss; break
        blocks[L] = b
    for L, b in blocks.items():
        for s in b.succ:
            if s is not None: blocks[s].preds.append(L)
    return entry, blocks

if __name__ == '__main__':
    protos = load()
    pid = int(sys.argv[1])
    f = prepare(protos[pid])
    entry, blocks = build_cfg(f)
    print('entry', entry, 'blocks', len(blocks))
    for L in sorted(blocks):
        b = blocks[L]
        print(L, b.kind, b.succ, [(pc, f.dec[pc][0]) for pc in b.pcs][:6])
