from dec3 import *
import keyword

LUAKW = set('and break do else elseif end false for function goto if in local nil not or repeat return then true until while continue'.split())
POOLNAMES = {4:'?pool4',6:'string.packsize',7:'bit32.rrotate',8:'bit32.bnot',9:'math.ceil',10:'math.pi',11:'bit32.bor',12:'bit32.rshift',
 13:'math.floor',14:'string.len',15:'bit32.band',16:'string.byte',17:'string.unpack',18:'bit32.bxor',19:'bit32.lshift',20:'math.modf',
 21:'bit32.countlz',22:'bit32.countrz',23:'bit32.lrotate'}
PREC = {'or':1,'and':2,'<':3,'>':3,'<=':3,'>=':3,'~=':3,'==':3,'..':5,'+':6,'-':6,'*':7,'/':7,'%':7,'^':9}

def lstr(b):
    try: s = b.decode('utf-8')
    except Exception: s = b.decode('latin-1')
    out = ['"']
    for ch in s:
        o = ord(ch)
        if ch == '"': out.append('\\"')
        elif ch == '\\': out.append('\\\\')
        elif ch == '\n': out.append('\\n')
        elif ch == '\r': out.append('\\r')
        elif ch == '\t': out.append('\\t')
        elif o < 32 or o == 127: out.append('\\%d' % o)
        else: out.append(ch)
    out.append('"'); return ''.join(out)
def isident(b):
    try: s = b.decode('ascii')
    except Exception: return False
    return re.match(r'^[A-Za-z_][A-Za-z_0-9]*$', s) is not None and s not in LUAKW
def lnum(v):
    if isinstance(v, bool): return 'true' if v else 'false'
    if isinstance(v, int): return str(v)
    if v != v: return '(0/0)'
    if v == float('inf'): return 'math.huge'
    if v == float('-inf'): return '-math.huge'
    if v == int(v) and abs(v) < 1e15: return str(int(v))
    return repr(v)

class Emitter:
    def __init__(self, protos, pid, upnames, depth=0):
        self.protos = protos; self.pid = pid; self.upnames = upnames; self.depth = depth
        f = prepare(protos[pid]); self.f = f
        r = analyze_func(f, protos)
        self.entry, self.blocks, self.stm, self.webs, self.wou, self.B = r
        self.nodes, self.defnode = inline_pass(f, self.blocks, self.stm, self.webs, self.wou, protos, self.B.def_web)
        self.names = {}; self.counter = 0; self.vararg = False; self.nparams = 0
        self.compute_graph()

    # ---------------------------------------------------- graph
    def compute_graph(self):
        blocks = self.blocks
        self.succ = {L: [s for s in b.succ if s is not None] for L, b in blocks.items()}
        order = rpo(self.entry, blocks); self.order = order
        idx = {L: i for i, L in enumerate(order)}
        def intersect(doms, a, b, idx):
            while a != b:
                while idx[a] > idx[b]: a = doms[a]
                while idx[b] > idx[a]: b = doms[b]
            return a
        doms = {self.entry: self.entry}
        changed = True
        while changed:
            changed = False
            for L in order[1:]:
                ps = [p for p in blocks[L].preds if p in doms]
                if not ps: continue
                nd = ps[0]
                for p in ps[1:]: nd = intersect(doms, p, nd, idx)
                if doms.get(L) != nd: doms[L] = nd; changed = True
        self.dom = doms
        # post-dominators on reversed graph with virtual exit
        EXIT = 'EXIT'
        rsucc = {L: list(self.succ[L]) for L in blocks}
        # blocks that can't reach exit -> connect
        rev = collections.defaultdict(list)
        for L, ss in rsucc.items():
            if not ss: rsucc[L] = [EXIT]
        def reach_exit():
            rv = collections.defaultdict(list)
            for L, ss in rsucc.items():
                for s in ss: rv[s].append(L)
            seen = {EXIT}; st = [EXIT]
            while st:
                x = st.pop()
                for y in rv[x]:
                    if y not in seen: seen.add(y); st.append(y)
            return seen
        re_ = reach_exit()
        for L in order:
            if L not in re_:
                rsucc[L] = rsucc[L] + [EXIT]; re_ = reach_exit()
        # postorder on reversed graph from EXIT
        preds_r = collections.defaultdict(list)
        for L, ss in rsucc.items():
            for s in ss: preds_r[s].append(L)    # predecessors in reversed graph == successors in original; here: rev-graph edges EXIT->L means L->EXIT
        seen = set(); po = []
        def dfs(x):
            seen.add(x)
            for y in preds_r[x]:
                if y not in seen: dfs(y)
            po.append(x)
        dfs(EXIT); rpo_r = list(reversed(po)); ridx = {x: i for i, x in enumerate(rpo_r)}
        pd = {EXIT: EXIT}; changed = True
        while changed:
            changed = False
            for L in rpo_r[1:]:
                ps = [s for s in rsucc[L] if s in pd]
                if not ps: continue
                nd = ps[0]
                for p in ps[1:]: nd = intersect(pd, p, nd, ridx)
                if pd.get(L) != nd: pd[L] = nd; changed = True
        self.ipdom = {L: (None if pd.get(L) in (EXIT, None) else pd[L]) for L in blocks}
        # loops
        self.loops = {}
        def dominates(a, b):
            while True:
                if a == b: return True
                if b == self.entry or b not in doms: return False
                nb = doms[b]
                if nb == b: return False
                b = nb
        for L in order:
            for s in self.succ[L]:
                if dominates(s, L) and blocks[s].kind not in ('forloop', 'tforloop'):
                    body = {s}; st = [L]
                    while st:
                        x = st.pop()
                        if x in body: continue
                        body.add(x); st.extend(blocks[x].preds)
                    self.loops.setdefault(s, set()).update(body)

    # ---------------------------------------------------- naming
    def webname(self, root):
        w = self.webs[root]
        if w.name is None:
            # parameter?
            pn = None
            for (sid, r) in w.defs:
                dn = self.defnode.get((sid, r))
                if dn is not None and dn.k == 'params': pn = r
            pre = 'vwxyzutsrq'[self.depth % 10] + (str(self.depth // 10) if self.depth >= 10 else '')
            if pn is not None: w.name = '%sa%d' % (pre, pn)
            else:
                self.counter += 1; w.name = '%s%d' % (pre, self.counter)
        return w.name
    def up(self, n):
        if isinstance(n, int) and 0 <= n < len(self.upnames) and self.upnames[n]: return self.upnames[n]
        return 'up%s' % (n,)

    # ---------------------------------------------------- expressions
    def ex(self, e, prec=0):
        t = e[0]
        if t == 'K':
            v = e[1]
            if v is None: return 'nil'
            if isinstance(v, tuple) and v[0] == 'S': return lstr(v[1])
            if isinstance(v, tuple): return '?' + str(v)
            return lnum(v)
        if t == 'V':
            self.on_use(e[1]); return self.webname(e[1])
        if t == 'R': return 'R%d' % e[1]
        if t == 'UP' or t == 'UPB': return self.up(e[1])
        if t == 'ENV':
            k = e[1]
            if isinstance(k, tuple) and k[0] == 'S':
                return k[1].decode('latin-1') if isident(k[1]) else '_G[%s]' % lstr(k[1])
            return '_G[?]'
        if t == 'POOL': return POOLNAMES.get(e[1], 'pool%d' % e[1])
        if t == 'TABLE': return '{}'
        if t == 'VARARG1': return '(...)'
        if t == 'VARARGS': return '...'
        if t == 'BXOR': return 'bit32.bxor(%s, %s)' % (self.ex(e[1]), self.ex(e[2]))
        if t == 'IDX': return self.idx(e)
        if t == 'UN':
            op = e[1]; a = self.ex(e[2], 8)
            r = ('not ' + a) if op == 'not' else (op + ('' if not a.startswith('-') else ' ') + a)
            return '(' + r + ')' if prec > 8 else r
        if t == 'BIN':
            op = e[1]; p = PREC[op]
            if op == '..': l = self.ex(e[2], p + 1); r = self.ex(e[3], p)
            elif op == '^': l = self.ex(e[2], p + 1); r = self.ex(e[3], p)
            else: l = self.ex(e[2], p); r = self.ex(e[3], p + 1)
            s = '%s %s %s' % (l, op, r)
            return '(' + s + ')' if prec > p else s
        if t == 'SELFFN': return self.ex(('IDX', e[1], e[2]))
        if t == 'SELFOBJ': return self.ex(e[1])
        if t == 'CALL': return self.call(e)
        if t == 'FUNC': return self.func(e)
        return '?%s' % t
    def prefix(self, e):
        s = self.ex(e, 10)
        if e[0] in ('K', 'BIN', 'UN', 'FUNC', 'TABLE') or (e[0] == 'V' and False): return '(' + s + ')'
        return s
    def idx(self, e):
        b, k = e[1], e[2]
        base = self.prefix(b)
        if k[0] == 'K' and isinstance(k[1], tuple) and k[1][0] == 'S' and isident(k[1][1]):
            return '%s.%s' % (base, k[1][1].decode('ascii'))
        return '%s[%s]' % (base, self.ex(k))
    def call(self, e):
        fe, args = e[1], e[2]
        if fe[0] == 'SELFFN' and args and args[0][0] == 'SELFOBJ' and fe[1] == args[0][1] and fe[2][0] == 'K' and isinstance(fe[2][1], tuple) and isident(fe[2][1][1]):
            return '%s:%s(%s)' % (self.prefix(fe[1]), fe[2][1][1].decode('ascii'), ', '.join(self.ex(a) for a in args[1:]))
        if fe[0] == 'POOL' or fe[0] in ('V', 'IDX', 'ENV', 'UP', 'UPB', 'CALL', 'SELFFN'): fs = self.prefix(fe) if fe[0] not in ('POOL',) else self.ex(fe)
        else: fs = '(' + self.ex(fe) + ')'
        return '%s(%s)' % (fs, ', '.join(self.ex(a) for a in args))
    def func(self, e):
        pid, caps = e[1], e[2]
        ups = []
        for c in caps:
            if c[0] == 'REG': self.on_use(c[1][1]); ups.append(self.webname(c[1][1]))
            else: ups.append(self.up(c[1]))
        em = Emitter(self.protos, pid, ups, self.depth + 1)
        return em.render_function()
    def negate(self, e):
        if e[0] == 'UN' and e[1] == 'not': return e[2]
        if e[0] == 'BIN' and e[1] == '==': return ('BIN', '~=', e[2], e[3])
        if e[0] == 'BIN' and e[1] == '~=': return ('BIN', '==', e[2], e[3])
        return ('UN', 'not', e)
    def on_use(self, root): pass
