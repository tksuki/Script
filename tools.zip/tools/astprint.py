import json, sys, collections
sys.setrecursionlimit(100000)
d = json.load(open('ast.json'))['root']

names = {}          # location -> unique name
counter = collections.Counter()
def lname(loc):
    nm = loc['name']; key = (nm, loc['location'])
    if key not in names:
        counter[nm] += 1
        names[key] = f"{nm}{counter[nm]}"
    return names[key]

def num(v):
    if isinstance(v, float) and v.is_integer() and abs(v) < 1e18: return str(int(v))
    if isinstance(v, float): return repr(v)
    return str(v)

def lstr(s):
    out = ['"']
    for ch in s:
        o = ord(ch)
        if ch == '"': out.append('\\"')
        elif ch == '\\': out.append('\\\\')
        elif ch == '\n': out.append('\\n')
        elif 32 <= o < 127: out.append(ch)
        else: out.append('\\u{%x}' % o)
    out.append('"'); return ''.join(out)

BIN = {'Add':'+','Sub':'-','Mul':'*','Div':'/','FloorDiv':'//','Mod':'%','Pow':'^','Concat':'..',
       'CompareNe':'~=','CompareEq':'==','CompareLt':'<','CompareLe':'<=','CompareGt':'>','CompareGe':'>=',
       'And':'and','Or':'or'}
UN = {'Not':'not ','Minus':'-','Len':'#'}
import re
IDENT = re.compile(r'^[A-Za-z_][A-Za-z_0-9]*$')

def ex(n):
    t = n['type']
    if t == 'AstExprLocal': return lname(n['local'])
    if t == 'AstExprGlobal': return n['global']
    if t == 'AstExprConstantNumber': return num(n['value'])
    if t == 'AstExprConstantString': return lstr(n['value'])
    if t == 'AstExprConstantNil': return 'nil'
    if t == 'AstExprConstantBool': return 'true' if n['value'] else 'false'
    if t == 'AstExprVarargs': return '...'
    if t == 'AstExprGroup': return '(' + ex(n['expr']) + ')'
    if t == 'AstExprIndexName':
        return ex(n['expr']) + n['op'] + n['index']
    if t == 'AstExprIndexExpr':
        return ex(n['expr']) + '[' + ex(n['index']) + ']'
    if t == 'AstExprBinary':
        return ex(n['left']) + ' ' + BIN[n['op']] + ' ' + ex(n['right'])
    if t == 'AstExprUnary':
        return UN[n['op']] + ex(n['expr'])
    if t == 'AstExprCall':
        return ex(n['func']) + '(' + ', '.join(ex(a) for a in n['args']) + ')'
    if t == 'AstExprTable':
        items=[]
        for it in n['items']:
            if it['kind']=='record':
                k=it['key']['value']
                items.append((k if IDENT.match(k) else '['+lstr(k)+']') + ' = ' + ex(it['value']))
            elif it['kind']=='general':
                items.append('[' + ex(it['key']) + '] = ' + ex(it['value']))
            else:
                items.append(ex(it['value']))
        return '{' + ', '.join(items) + '}'
    if t == 'AstExprFunction':
        args = [lname(a) for a in n['args']]
        if n['vararg']: args.append('...')
        body = blk(n['body'], 1)
        return 'function(' + ', '.join(args) + ')\n' + body + 'end'
    raise Exception('expr ' + t)

def indent(s, lvl): 
    return ''.join(('  '*lvl + l if l.strip() else l) + '\n' for l in s.split('\n') if l is not None) 

def blk(n, lvl):
    out = []
    for s in n['body']:
        x = st(s)
        if x.startswith('(') and out: out[-1] += ';'
        out.append(x)
    txt = '\n'.join(out)
    lines = txt.split('\n')
    return ''.join('  ' + l + '\n' for l in lines) if txt else ''

def st(n):
    t = n['type']
    if t == 'AstStatBlock':
        return 'do\n' + blk(n,1) + 'end'
    if t == 'AstStatReturn':
        return 'return ' + ', '.join(ex(e) for e in n['list']) if n['list'] else 'return'
    if t == 'AstStatAssign':
        return ', '.join(ex(v) for v in n['vars']) + ' = ' + ', '.join(ex(v) for v in n['values'])
    if t == 'AstStatLocal':
        s = 'local ' + ', '.join(lname(v) for v in n['vars'])
        if n['values']: s += ' = ' + ', '.join(ex(v) for v in n['values'])
        return s
    if t == 'AstStatCompoundAssign':
        return ex(n['var']) + ' ' + BIN[n['op']] + '= ' + ex(n['value'])
    if t == 'AstStatExpr':
        return ex(n['expr'])
    if t == 'AstStatBreak': return 'break'
    if t == 'AstStatContinue': return 'continue'
    if t == 'AstStatIf':
        s = 'if ' + ex(n['condition']) + ' then\n' + blk(n['thenbody'],1)
        e = n.get('elsebody')
        while e is not None:
            if e['type'] == 'AstStatIf':
                s += 'elseif ' + ex(e['condition']) + ' then\n' + blk(e['thenbody'],1)
                e = e.get('elsebody')
            else:
                s += 'else\n' + blk(e,1); e = None
        return s + 'end'
    if t == 'AstStatWhile':
        return 'while ' + ex(n['condition']) + ' do\n' + blk(n['body'],1) + 'end'
    if t == 'AstStatRepeat':
        return 'repeat\n' + blk(n['body'],1) + 'until ' + ex(n['condition'])
    if t == 'AstStatFor':
        s = 'for ' + lname(n['var']) + ' = ' + ex(n['from']) + ', ' + ex(n['to'])
        if n.get('step'): s += ', ' + ex(n['step'])
        return s + ' do\n' + blk(n['body'],1) + 'end'
    if t == 'AstStatForIn':
        return 'for ' + ', '.join(lname(v) for v in n['vars']) + ' in ' + ', '.join(ex(v) for v in n['values']) + ' do\n' + blk(n['body'],1) + 'end'
    raise Exception('stat ' + t)

out = '\n'.join(st(s) for s in d['body'])
open('pretty.lua','w').write(out)
print('written', len(out), 'chars,', out.count('\n'), 'lines')
