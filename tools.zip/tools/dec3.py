from dec2 import *

class Web:
    __slots__ = ('defs','nuses','undef','name','noinline','params')
    def __init__(self): self.defs = set(); self.nuses = 0; self.undef = False; self.name = None; self.noinline = False; self.params = None

def rpo(entry, blocks):
    seen = set(); order = []
    def dfs(L):
        seen.add(L)
        for s in blocks[L].succ:
            if s is not None and s not in seen: dfs(s)
        order.append(L)
    dfs(entry); order.reverse(); return order

def analyze_func(f, protos):
    entry, blocks = build_cfg(f)
    B = Builder(f); B.protos = protos
    stm = {L: build_stmts(f, blocks[L], B) for L in blocks}
    order = rpo(entry, blocks)
    # reaching definitions
    IN = {L: {} for L in blocks}; OUT = {L: None for L in blocks}
    usedefs = {}
    def transfer(L, record):
        cur = {r: set(ds) for r, ds in IN[L].items()}
        for s in stm[L]:
            for (uid, r) in s.uses:
                ds = cur.get(r)
                if record: usedefs[uid] = set(ds) if ds else {('undef', r)}
            for r in s.dsts: cur[r] = {(s.id, r)}
        return cur
    changed = True; it = 0
    while changed and it < 60:
        changed = False; it += 1
        for L in order:
            new = {}
            for pl in blocks[L].preds:
                if OUT[pl] is None: continue
                for r, ds in OUT[pl].items(): new.setdefault(r, set()).update(ds)
            IN[L] = new
            o = transfer(L, False)
            if OUT[L] != o: OUT[L] = o; changed = True
    for L in order: transfer(L, True)
    # union-find webs
    parent = {}
    def find(x):
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]; x = parent[x]
        return x
    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb: parent[ra] = rb
    for L in blocks:
        for s in stm[L]:
            for r in s.dsts: find((s.id, r))
    for uid, ds in usedefs.items():
        ds = list(ds)
        for d in ds[1:]: union(ds[0], d)
        find(ds[0])
    webs = {}
    for L in blocks:
        for s in stm[L]:
            for r in s.dsts:
                w = webs.setdefault(find((s.id, r)), Web()); w.defs.add((s.id, r))
    for uid, ds in usedefs.items():
        root = find(next(iter(ds)))
        w = webs.setdefault(root, Web()); w.nuses += 1
        if any(d[0] == 'undef' for d in ds): w.undef = True
    web_of_use = {uid: find(next(iter(ds))) for uid, ds in usedefs.items()}
    def_web = {}
    for L in blocks:
        for s in stm[L]:
            for r in s.dsts: def_web[(s.id, r)] = find((s.id, r))
    B.def_web = def_web
    return entry, blocks, stm, webs, web_of_use, B

def subst(e, fn):
    t = e[0]
    if t == 'R': return fn(e)
    if t == 'BIN': return ('BIN', e[1], subst(e[2], fn), subst(e[3], fn))
    if t == 'UN': return ('UN', e[1], subst(e[2], fn))
    if t == 'IDX': return ('IDX', subst(e[1], fn), subst(e[2], fn))
    if t == 'BXOR': return ('BXOR', subst(e[1], fn), subst(e[2], fn))
    if t == 'CALL': return ('CALL', subst(e[1], fn), [subst(a, fn) for a in e[2]])
    if t == 'SELFFN': return ('SELFFN', subst(e[1], fn), e[2])
    if t == 'SELFOBJ': return ('SELFOBJ', subst(e[1], fn))
    if t == 'FUNC': return ('FUNC', e[1], [(c[0], subst(c[1], lambda x: ('V', web_of_use_g[x[2]]))) if c[0] == 'REG' else c for c in e[2]])
    return e

def has_call(e):
    t = e[0]
    if t == 'CALL': return True
    if t in ('BIN',): return has_call(e[2]) or has_call(e[3])
    if t in ('UN', 'SELFOBJ'): return has_call(e[-1])
    if t == 'SELFFN': return has_call(e[1])
    if t in ('IDX', 'BXOR'): return has_call(e[1]) or has_call(e[2])
    return False

web_of_use_g = {}
def inline_pass(f, blocks, stm, webs, web_of_use, protos, B_def_web):
    global web_of_use_g
    web_of_use_g = web_of_use
    defnode = {}
    for L in blocks:
        for s in stm[L]:
            for r in s.dsts: defnode[(s.id, r)] = s
    nodes = {}
    for L, stmts in stm.items():
        out = []; outset = set()
        for s in stmts:
            skip = set()
            if s.k == 'assign' and s.e[0] == 'FUNC':
                for c in s.e[2]:
                    if c[0] == 'REG': skip.add(c[1][2])
            if s.k == 'tforprep' and out and out[-1].k == 'multiassign' and out[-1].e == ('K', None):
                A = s.extra; ln = out[-1]
                if ln.dsts == [A + 1, A + 2]:
                    ws = [webs[B_def_web[(ln.id, r)]] for r in ln.dsts]
                    if all(len(w.defs) == 1 and w.nuses == 1 for w in ws):
                        out.pop(); outset.discard(ln); ln.dead = True
                        s.uses = [u for u in s.uses if u[1] == A]; s.vals = [s.vals[0]]
            cands = []
            for (uid, r) in s.uses:
                if uid in skip: continue
                w = webs[web_of_use[uid]]
                if len(w.defs) == 1 and not w.undef and w.nuses == 1 and not w.noinline:
                    dn = defnode[next(iter(w.defs))]
                    if dn.k == 'assign' and dn in outset and dn.blk == s.blk and dn.dead is False:
                        cands.append((uid, dn))
            inl = {}
            p = len(out)
            for (uid, dn) in reversed(cands):
                fe = dn.e
                if fe[0] == 'K' and dn in outset:      # constants commute
                    inl[uid] = dn; out.remove(dn); outset.discard(dn); p = len(out); continue
                if p > 0 and out[p - 1] is dn:
                    inl[uid] = dn; out.pop(); outset.discard(dn); p -= 1
                else: break
            def fn(leaf, inl=inl):
                uid = leaf[2]
                if uid in inl: return inl[uid].e
                return ('V', web_of_use[uid])
            def fnv(leaf): return ('V', web_of_use[leaf[2]])
            def resolve_expr(e):
                if e[0] == 'FUNC': return ('FUNC', e[1], [(c[0], fnv(c[1])) if c[0] == 'REG' else c for c in e[2]])
                return subst(e, fn)
            if s.k in ('assign', 'multiassign', 'callstmt', 'cond'):
                if s.alias is not None:
                    s.e = ('SELFOBJ', s.alias.e[1])
                else: s.e = resolve_expr(s.e)
            elif s.k == 'store':
                s.t = subst(s.t, fn) if s.t[0] == 'IDX' else s.t
                s.v = subst(s.v, fn)
            elif s.k == 'setlist':
                s.t = subst(s.t, fn); s.vals = [subst(v, fn) for v in s.vals]
            elif s.k in ('ret',): s.vals = [subst(v, fn) for v in s.vals]
            elif s.k in ('forprep', 'tforprep'):
                s.vals = [subst(v, fn) for v in s.vals]
            if s.k == 'assign' and s.alias is None and s.dsts and webs[B_def_web[(s.id, s.dsts[0])]].nuses == 0 and len(webs[B_def_web[(s.id, s.dsts[0])]].defs) == 1:
                if has_call(s.e): s.k = 'callstmt'
                else:
                    s.dead = True; continue
            out.append(s); outset.add(s)
        nodes[L] = out
    return nodes, defnode
