import re, collections, sys, math
# ---------- parsing ----------
def parse_val(s):
    if s == 'nil': return None
    if s == 'true': return True
    if s == 'false': return False
    if s.startswith('s"'): return ('S', bytes.fromhex(s[2:-1]))
    if s.startswith('P') and s[1:].isdigit(): return ('P', int(s[1:]))
    if s == 'nan': return float('nan')
    if s == 'inf': return float('inf')
    if s == '-inf': return float('-inf')
    try: return int(s)
    except: pass
    try: return float(s)
    except: return ('?', s)
MISSING = object()
def load(path='protos.txt'):
    protos = {}
    cur = None
    pat = re.compile(r'\[I\] (\d+) (\d+) op=(\S+) g=(\S+) G=(\S+) o=(\S+) C=(\S+) a=(\S+) p=(\S+)')
    for l in open(path):
        if l.startswith('[P]'):
            m = re.match(r'\[P\] id=(\d+) regs=(\d+) n=(\d+) ups=(.*)', l.strip())
            pid = int(m.group(1))
            ups = []
            if m.group(4):
                for u in m.group(4).split(','):
                    a, b = u.split(':'); ups.append((int(a), int(b)))
            protos[pid] = dict(id=pid, regs=int(m.group(2)), n=int(m.group(3)), ups=ups, ins={})
        elif l.startswith('[I]'):
            m = pat.match(l.strip())
            pid, pc = int(m.group(1)), int(m.group(2))
            f = [parse_val(x) for x in m.groups()[2:]]
            protos[pid]['ins'][pc] = dict(op=f[0], g=f[1], G=f[2], o=f[3], C=f[4], a=f[5], p=f[6])
    return protos

# ---------- expression nodes ----------
def R(n): return ('R', n)
def K(v): return ('K', v)
def BIN(op, a, b): return ('BIN', op, a, b)
def UN(op, a): return ('UN', op, a)
def IDX(t, k): return ('IDX', t, k)

JUNK_OPS = set([41,83,87,92,139,142]) | set(range(144, 256))
NOP_OPS = set([21, 29, 43])
CLOSE_OPS = set([42, 67])

def decode(ins):
    """returns (kind, data...)  kinds: set, store, jump, cjump, call, ret, loop*, nop, junk, closure, ..."""
    op, g, G, o, C, a, p = ins['op'], ins['g'], ins['G'], ins['o'], ins['C'], ins['a'], ins['p']
    s = lambda d, e: ('set', d, e)
    B = BIN
    t = {
     0: lambda: s(G, B('>=', R(g), R(o))), 1: lambda: s(g, ('TABLE',)), 6: lambda: s(o, B('-', K(a), R(G))),
     7: lambda: s(g, ('BXOR', R(G), K(C))), 8: lambda: s(g, B('<=', K(p), K(C))),
     9: lambda: s(g, IDX(('UP', G), K(C))), 11: lambda: s(G, ('TABLE',)),
     12: lambda: s(G, B('/', R(g), R(o))), 14: lambda: s(o, B('*', R(G), K(a))), 15: lambda: s(g, B('>', R(o), R(G))),
     17: lambda: s(o, B('%', R(g), R(G))), 20: lambda: s(o, B('<', R(G), R(g))),
     22: lambda: s(G, B('+', R(o), K(a))), 23: lambda: s(g, B('*', K(p), R(o))), 28: lambda: s(G, UN('not', R(g))),
     30: lambda: s(o, B('%', R(g), K(p))), 32: lambda: s(o, B('/', K(a), R(G))), 34: lambda: s(o, B('<', K(p), R(g))),
     36: lambda: s(g, B('^', K(p), R(o))), 37: lambda: s(G, B('>', K(a), R(o))), 45: lambda: s(o, B('==', R(G), K(a))),
     46: lambda: s(G, B('-', R(g), R(o))), 47: lambda: s(g, B('..', R(o), R(G))), 49: lambda: s(G, ('BXOR', R(o), R(g))),
     51: lambda: s(g, B('<=', R(G), K(C))), 52: lambda: s(o, ('ENV', a)), 56: lambda: s(o, IDX(('UPB', G), R(g))),
     58: lambda: s(G, B('==', K(C), K(a))), 59: lambda: s(o, IDX(R(G), K(a))), 62: lambda: s(G, B('+', K(C), R(g))),
     63: lambda: s(o, ('VARARG1',)), 65: lambda: s(G, K(C)), 66: lambda: s(g, ('UPB', o)),
     68: lambda: s(g, ('POOL', G)), 71: lambda: s(G, IDX(('UPB', o), K(a))), 72: lambda: s(G, B('*', R(o), R(g))),
     73: lambda: s(o, B('>=', K(a), K(p))), 74: lambda: s(o, B('>', R(G), K(a))), 75: lambda: s(G, B('~=', K(C), K(a))),
     76: lambda: s(g, B('+', K(p), K(C))), 77: lambda: s(G, R(g)), 79: lambda: s(g, B('~=', R(o), R(G))),
     82: lambda: s(o, UN('-', R(g))), 91: lambda: s(o, B('>=', R(G), K(a))), 94: lambda: s(o, B('..', K(p), R(g))),
     95: lambda: s(G, ('UP', g)), 101: lambda: s(o, B('~=', K(p), R(g))), 102: lambda: s(G, B('%', K(C), K(a))),
     103: lambda: s(g, B('~=', R(G), K(C))), 104: lambda: s(G, B('-', R(g), K(C))), 105: lambda: s(o, B('/', R(g), K(p))),
     109: lambda: s(o, B('..', K(a), K(p))), 111: lambda: s(G, B('<', R(g), K(C))), 112: lambda: s(g, UN('#', R(o))),
     113: lambda: s(o, B('^', R(g), R(G))), 117: lambda: s(g, IDX(R(o), R(G))), 118: lambda: s(o, B('-', K(p), K(a))),
     119: lambda: s(g, B('>=', K(p), R(o))), 120: lambda: s(g, B('==', R(G), R(o))), 125: lambda: s(g, B('+', R(G), R(o))),
     127: lambda: s(g, B('<=', K(p), R(o))), 133: lambda: s(G, B('<=', R(o), R(g))),
     136: lambda: s(g, IDX(('UP', o), R(G))), 138: lambda: s(o, B('<', K(p), K(a))), 141: lambda: s(g, B('..', R(o), K(p))),
     143: lambda: s(g, K(None)),
     16: lambda: s(o, ('ENV', a)), 50: lambda: s(o, UN('-', R(g))), 55: lambda: s(o, B('-', K(p), K(a))), 93: lambda: s(g, B('+', R(o), R(G))),
     122: lambda: ('store', ('UPB', G), R(g)),
     # stores
     24: lambda: ('store', IDX(('UP', g), R(G)), K(C)), 27: lambda: ('store', IDX(('UPB', o), K(p)), K(a)),
     35: lambda: ('store', ('UPB', G), R(g)), 39: lambda: ('store', IDX(R(G), R(o)), K(a)),
     48: lambda: ('store', IDX(('UP', o), R(G)), R(g)), 53: lambda: ('store', ('ENV', a), K(p)),
     57: lambda: ('store', IDX(('UPB', g), K(C)), R(G)), 69: lambda: ('store', IDX(R(o), K(p)), K(a)),
     81: lambda: ('store', IDX(R(g), K(C)), R(G)), 86: lambda: ('store', IDX(('UP', o), K(a)), R(G)),
     88: lambda: ('store', IDX(('UPB', G), R(o)), R(g)), 107: lambda: ('store', ('ENV', p), R(o)),
     114: lambda: ('store', IDX(('UP', g), K(p)), K(C)), 131: lambda: ('store', IDX(R(G), R(o)), R(g)),
     135: lambda: ('store', ('UPB', G), K(C)),
     # jumps: ('jump', target) / ('cjump', condexpr, target)  (jump taken when condexpr true)
     13: lambda: ('jump', g), 137: lambda: ('jump', g),
     99: lambda: ('cjump', UN('not', B('<=', R(g), K(p))), o),
     4: lambda: ('cjump', UN('not', B('<', R(g), K(C))), G),
     5: lambda: ('cjump', UN('not', B('<=', K(C), R(G))), g),
     10: lambda: ('cjump', B('~=', R(G), K(C)), g),
     25: lambda: ('cjump', B('<', K(a), R(G)), o),
     26: lambda: ('cjump', B('==', R(G), K(a)), o),
     33: lambda: ('cjump', UN('not', B('<=', R(G), R(o))), g),
     38: lambda: ('cjump', UN('not', B('<', R(G), R(o))), g),
     60: lambda: ('cjump', UN('not', B('<=', R(g), K(p))), o),
     61: lambda: ('cjump', R(G), o),
     80: lambda: ('cjump', B('~=', R(o), R(G)), g),
     89: lambda: ('cjump', B('==', R(g), R(o)), G),
     116: lambda: ('cjump', UN('not', R(G)), o),
     132: lambda: ('cjump', UN('not', B('<', K(a), R(o))), G),
     # calls: ('call', A, B, C)
     3: lambda: ('call', o, 1, 1), 19: lambda: ('call', o, g, 1), 44: lambda: ('call', G, 1, 2),
     70: lambda: ('call', G, 2, 2), 85: lambda: ('call', G, g, 2), 98: lambda: ('call', o, 0, 2),
     106: lambda: ('call', o, 3, 1), 123: lambda: ('call', G, 2, 1), 130: lambda: ('call', G, 0, 1),
     140: lambda: ('call', G, 3, 2), 115: lambda: ('call', g, o, G),
     # returns: ('ret', first, count|None(open))   count form
     90: lambda: ('ret', g, None), 110: lambda: ('ret', G, g - 1),
     121: lambda: ('ret', o, 1), 18: lambda: ('ret', 0, 0),
     108: lambda: ('tail', G, 2), 124: lambda: ('tail', G, 0), 128: lambda: ('tail', g, G), 134: lambda: ('tail', g, 1),
     # misc
     2: lambda: ('params', g, False), 129: lambda: ('params', g, True), 64: lambda: ('vararg', g),
     40: lambda: ('self', o, g, K(p)), 54: lambda: ('setlist', o, g, G), 84: lambda: ('setlist', g, None, G),
     96: lambda: ('closure', G, a), 97: lambda: ('loadnil', G, o),
     31: lambda: ('forprep', o, G), 100: lambda: ('forloop', G, g), 78: lambda: ('tforprep', g, G), 126: lambda: ('tforloop', g, G),
    }
    if op in CLOSE_OPS or op in NOP_OPS: return ('nop',)
    if op in JUNK_OPS: return ('junk', op)
    if op not in t: return ('unknown', op)
    return t[op]()

def succs(pc, d):
    k = d[0]
    if k in ('jump',): return [d[1] + 1]
    if k == 'cjump': return [pc + 1, d[2] + 1]
    if k in ('ret', 'tail'): return []
    if k == 'forprep': return [d[2] + 1]
    if k == 'tforprep': return [d[2] + 1]
    if k == 'forloop': return [pc + 1, d[2] + 1]
    if k == 'tforloop': return [pc + 1, d[2] + 1]
    return [pc + 1]

def reachable(p, entry=1):
    seen, order, st = set(), [], [entry]
    while st:
        pc = st.pop()
        if pc in seen or pc not in p['ins']: continue
        seen.add(pc); order.append(pc)
        d = decode(p['ins'][pc])
        for s in succs(pc, d): st.append(s)
    return seen

if __name__ == '__main__':
    protos = load()
    print(len(protos), 'protos')
    hist = collections.Counter(); tot = 0
    unk = collections.Counter(); junkc = collections.Counter(); missing_targets = 0
    for pid, p in protos.items():
        seen = reachable(p)
        tot += len(seen)
        for pc in seen:
            d = decode(p['ins'][pc]); hist[d[0]] += 1
            if d[0] == 'unknown': unk[d[1]] += 1
            if d[0] == 'junk': junkc[d[1]] += 1
        # dangling successors
        for pc in seen:
            for s in succs(pc, decode(p['ins'][pc])):
                if s not in p['ins']: missing_targets += 1
    print('reachable instrs', tot, 'of', sum(len(p['ins']) for p in protos.values()))
    print('kinds', dict(hist)); print('unknown', dict(unk)); print('junk', dict(junkc)); print('dangling', missing_targets)
