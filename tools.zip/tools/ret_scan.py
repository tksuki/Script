exec(open('extract_ops.py').read().split("visit(rest, ALL)")[0])
import re
rets = []   # (opset, kind, text)
def visit2(stmts, cur):
    for s in stmts:
        t = s['type']
        if t == 'AstStatIf':
            node = s; c = cur
            while node is not None and node['type'] == 'AstStatIf':
                tt, ff = cond(node['condition'])
                visit2(node['thenbody']['body'], c & tt)
                c = c & ff; node = node.get('elsebody')
            if node is not None: visit2(node['body'], c)
        elif t in ('AstStatWhile', 'AstStatRepeat', 'AstStatFor', 'AstStatForIn'):
            visit2(s['body']['body'], cur)
        elif t == 'AstStatBlock': visit2(s['body'], cur)
        elif t == 'AstStatReturn' and cur:
            rets.append((cur, st(s)))
visit2(rest, ALL)
import collections
per = collections.defaultdict(list)
for opset, text in rets:
    if len(opset) <= 3:
        for v in sorted(opset): per[v].append(text[:80])
for v in sorted(per): print(v, sorted(set(per[v]))[:4])
print('wide (junk) returns:', sum(1 for o,t in rets if len(o) > 3))
