-- ===== logging mock environment =====
local LOG = {}
local _rawprint = print
local function log(...)
    local t = table.pack(...)
    local parts = {}
    for i = 1, t.n do parts[#parts+1] = tostring(t[i]) end
    _rawprint("[LOG] " .. table.concat(parts, " "))
end

local proxies = setmetatable({}, {__mode = "k"})
local mkproxy
local function pathof(p) return proxies[p] or "?" end
local function fmt(v)
    if proxies[v] then return "<" .. proxies[v] .. ">" end
    if type(v) == "string" then return string.format("%q", v) end
    if type(v) == "function" then return "<function>" end
    if type(v) == "table" then return "<table>" end
    return tostring(v)
end
local function fmtargs(...)
    local t = table.pack(...)
    local out = {}
    for i = 1, t.n do out[#out+1] = fmt(t[i]) end
    return table.concat(out, ", ")
end

mkproxy = function(path)
    local p = {}
    proxies[p] = path
    setmetatable(p, {
        __index = function(self, k)
            local np = mkproxy(path .. "." .. tostring(k))
            rawset(self, k, np)
            log("INDEX", path .. "." .. tostring(k))
            return np
        end,
        __newindex = function(self, k, v)
            log("NEWINDEX", path .. "." .. tostring(k) .. " = " .. fmt(v))
            rawset(self, k, v)
        end,
        __call = function(self, ...)
            log("CALL", path .. "(" .. fmtargs(...) .. ")")
            return mkproxy(path .. "()")
        end,
        __add = function() return 1 end, __sub = function() return 1 end,
        __mul = function() return 1 end, __div = function() return 1 end,
        __mod = function() return 1 end, __pow = function() return 1 end,
        __unm = function() return 0 end,
        __concat = function(a, b) return fmt(a) .. fmt(b) end,
        __len = function() return 0 end,
        __lt = function() return false end, __le = function() return false end,
        __tostring = function() return "<" .. path .. ">" end,
    })
    return p
end

game = mkproxy("game")
workspace = mkproxy("workspace")
script = mkproxy("script")
Enum = mkproxy("Enum")
Instance = mkproxy("Instance")
Vector3 = mkproxy("Vector3")
CFrame = mkproxy("CFrame")
Color3 = mkproxy("Color3")
UDim2 = mkproxy("UDim2")
task = { wait = function(t) log("task.wait", tostring(t)) return 0 end,
         spawn = function(f, ...) log("task.spawn") return f(...) end,
         delay = function(t, f, ...) log("task.delay", tostring(t)) return f(...) end,
         defer = function(f, ...) log("task.defer") return f(...) end }
wait = function(t) log("wait", tostring(t)) return 0 end
spawn = function(f, ...) log("spawn") return f(...) end
tick = function() return os.clock() end
time = os.clock
typeof = function(v) if proxies[v] then return "Instance" end return type(v) end
shared = {}

local _print = print
print = function(...) local t = table.pack(...) local o = {} for i=1,t.n do o[#o+1]=fmt(t[i]) end _print("[PRINT] " .. table.concat(o, "\t")) end
warn = function(...) local t = table.pack(...) local o = {} for i=1,t.n do o[#o+1]=fmt(t[i]) end _print("[WARN] " .. table.concat(o, "\t")) end
local _loadstring = loadstring
loadstring = function(s, ...)
    _print("[LOADSTRING] len=" .. tostring(s and #s))
    local f = io and io.open and io.open("dump_loadstring.lua", "wb")
    _print("[LOADSTRING-SRC-BEGIN]\n" .. tostring(s) .. "\n[LOADSTRING-SRC-END]")
    if _loadstring then return _loadstring(s, ...) end
    return nil, "no loadstring"
end
local __ge = setmetatable({}, {
  __index = function(t,k) return rawget(_G,k) end,
  __newindex = function(t,k,v) _rawprint("[GETGENV-SET] "..tostring(k).." = "..fmt(v)); rawset(t,k,v) end })
getgenv = function() _rawprint("[CALL] getgenv()") return __ge end
getfenv_orig = getfenv
-- ===== end mock =====

PLACEID = PLACEID or nil
