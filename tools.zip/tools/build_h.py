import sys
m=open('/home/claude/work/mock_prefix.lua').read()
body=open('/home/claude/work/Test.obf',encoding='utf-8').read()
extra_mock = r'''
-- ---- extra: loop guard, connection capture, executor stubs ----
local waitcount = 0
local function guard(name)
    waitcount += 1
    if waitcount > 300 then error("LOOPGUARD: too many "..name.." calls") end
end
task.wait = function(t) guard("task.wait") return 0.03 end
wait = function(t) guard("wait") return 0.03 end
local o_delay = task.delay
task.delay = function(t, f, ...) _rawprint("[LOG] task.delay "..tostring(t)) return f(...) end
task.spawn = function(f, ...) _rawprint("[LOG] task.spawn") if type(f)=="function" then return f(...) end end
task.defer = function(f, ...) _rawprint("[LOG] task.defer") if type(f)=="function" then return f(...) end end
spawn = task.spawn

CONNECTIONS = {}
-- patch mkproxy's call to capture Connect callbacks: wrap via post-processing of __call
local o_mkproxy = mkproxy
mkproxy = function(path)
    local p = o_mkproxy(path)
    local mt = getmetatable(p)
    local oc = mt.__call
    mt.__call = function(self, ...)
        local args = table.pack(...)
        if path:match("[%.:]Connect$") or path:match("%.Connect$") or path:match("Once$") then
            for i = 1, args.n do
                if type(args[i]) == "function" then CONNECTIONS[#CONNECTIONS+1] = {path = path, fn = args[i]} end
            end
        end
        return oc(self, ...)
    end
    return p
end
-- re-create base proxies with the patched mkproxy
game = mkproxy("game"); workspace = mkproxy("workspace"); script = mkproxy("script")
Enum = mkproxy("Enum"); Instance = mkproxy("Instance"); Vector3 = mkproxy("Vector3")
Vector2 = mkproxy("Vector2"); CFrame = mkproxy("CFrame"); Color3 = mkproxy("Color3")
UDim2 = mkproxy("UDim2"); UDim = mkproxy("UDim"); TweenInfo = mkproxy("TweenInfo")
Random = mkproxy("Random"); Ray = mkproxy("Ray"); Rect = mkproxy("Rect")
ColorSequence = mkproxy("ColorSequence"); NumberSequence = mkproxy("NumberSequence"); NumberRange = mkproxy("NumberRange")
ColorSequenceKeypoint = mkproxy("ColorSequenceKeypoint"); NumberSequenceKeypoint = mkproxy("NumberSequenceKeypoint")
Font = mkproxy("Font"); BrickColor = mkproxy("BrickColor"); RaycastParams = mkproxy("RaycastParams")
OverlapParams = mkproxy("OverlapParams"); PhysicsService = mkproxy("PhysicsService")
'''
final_part = r'''
-- error visibility hooks
local o_pcall, o_xpcall, o_error = pcall, xpcall, error
local errseen = {}
local function noteerr(tag, e)
    local m = tostring(e)
    if not errseen[m] then errseen[m] = true; _rawprint("[ERR-"..tag.."] "..m:sub(1,300)) end
end
pcall = function(f, ...)
    local r = table.pack(o_pcall(f, ...))
    if r[1] == false then noteerr("pcall", r[2]) end
    return table.unpack(r, 1, r.n)
end
xpcall = function(f, h, ...)
    local r = table.pack(o_xpcall(f, function(e) noteerr("xpcall", e) return h and h(e) or e end, ...))
    return table.unpack(r, 1, r.n)
end
error = function(e, l) noteerr("error", e) return o_error(e, l) end
-- fallback for undefined globals: logged callable stub (executor-style APIs)
local realG = getfenv(0)
local gseen = {}
local noisy = {string=1,bit32=1,coroutine=1,math=1,setfenv=1,unpack=1,select=1,table=1,setmetatable=1,error=1,pcall=1,tostring=1,type=1,getfenv=1,next=1,xpcall=1,rawset=1,getmetatable=1,rawget=1,assert=1,tonumber=1,pairs=1,ipairs=1,os=1,utf8=1,rawequal=1,rawlen=1}
local genv = setmetatable({}, {
  __index = function(_, k)
     local v = realG[k]
     if v == nil then
        if not gseen[k] then gseen[k] = true; _rawprint("[GGET-UNDEF->stub] "..tostring(k)) end
        local p = mkproxy("G:"..tostring(k))
        realG[k] = p
        return p
     end
     if not gseen[k] and not noisy[k] then gseen[k] = true; _rawprint("[GGET] "..tostring(k)) end
     return v
  end,
  __newindex = function(_, k, v) _rawprint("[GSET] "..tostring(k).." = "..fmt(v)); realG[k] = v end,
})
'''
placeid = sys.argv[1] if len(sys.argv)>1 else '6961824067'
src = m + extra_mock + final_part + f"\nrawset(game,'PlaceId',{placeid})\nrawset(game,'GameId',1)\nlocal function __main(...)\n"+body+"\nend\nsetfenv(__main, genv)\nlocal ok, res = pcall(__main)\n_rawprint('[DONE] ok='..tostring(ok)..' res='..fmt(res))\n_rawprint('[CONNECTIONS] '..#CONNECTIONS)\n"
open('/home/claude/work/harness6.lua','w',encoding='utf-8').write(src)
