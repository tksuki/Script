from lift import *
import copy
ARRFIELD = {'g': 'g', 'G': 'G', 'o': 'o'}
def collect_patches(p):
    arrs = {}
    patches = collections.defaultdict(set)   # (kind, idx) -> set(values)
    other = collections.Counter()
    for pc in sorted(p['ins']):
        ins = p['ins'][pc]; op = ins['op']
        if op == 92 and ins['G'] is not None: arrs[ins['G']] = 'g'
        elif op == 87 and ins['o'] is not None: arrs[ins['o']] = 'G'
        elif op == 142 and ins['G'] is not None: arrs[ins['G']] = 'o'
        elif op == 83 and ins['g'] is not None: arrs[ins['g']] = '_'
        elif op == 139 and ins['G'] is not None: arrs[ins['G']] = 'R'
        elif op == 41 and ins['g'] is not None: arrs[ins['g']] = 'H'
        elif op == 143 and ins['g'] in arrs: arrs.pop(ins['g'])
        elif op == 69 and ins['o'] in arrs:
            if isinstance(ins['p'], int) and isinstance(ins['a'], (int, float)) and not isinstance(ins['a'], bool):
                patches[(arrs[ins['o']], ins['p'])].add(ins['a'])
        elif op in (39, 81, 131) :
            other[op] += 1
    return patches, other
if __name__ == '__main__':
    protos = load()
    tot = 0; conflicts = 0; kinds = collections.Counter(); others = collections.Counter()
    for pid, p in protos.items():
        pt, other = collect_patches(p)
        others.update(other)
        for (k, idx), vals in pt.items():
            tot += 1; kinds[k] += 1
            if len(vals) > 1: conflicts += 1
    print('patches', tot, 'conflicts', conflicts, dict(kinds), 'other-table-sets', dict(others))

def apply_patches(p):
    pt, _ = collect_patches(p)
    q = copy.deepcopy(p)
    newins = 0; conflict = []
    for (kind, idx), vals in pt.items():
        if kind not in ('g', 'G', 'o', '_'): continue
        if len(vals) > 1: conflict.append((kind, idx, vals)); 
        v = sorted(vals, key=lambda x: (x is None, str(x)))[0]
        if idx not in q['ins']:
            q['ins'][idx] = dict(op=None, g=None, G=None, o=None, C=None, a=None, p=None); newins += 1
        fld = 'op' if kind == '_' else kind
        q['ins'][idx][fld] = v
    return q, conflict, newins

def safe_decode(ins):
    try: return decode(ins)
    except Exception: return ('bad',)

def analyze(q):
    seen = set(); st = [1]; bad = collections.Counter(); kinds = collections.Counter()
    while st:
        pc = st.pop()
        if pc in seen or pc not in q['ins']: continue
        seen.add(pc)
        d = safe_decode(q['ins'][pc]); kinds[d[0]] += 1
        if d[0] in ('bad', 'unknown') or (d[0] in ('jump','cjump','forprep','tforprep','forloop','tforloop') and any(x is None for x in d[1:])):
            bad[q['ins'][pc]['op']] += 1; continue
        for s in succs(pc, d): st.append(s)
    return seen, bad, kinds
if __name__ == '__main__':
    tc = 0; tb = collections.Counter(); tk = collections.Counter(); tn = 0; reach = 0
    shown = 0
    for pid, p in protos.items():
        q, conf, newins = apply_patches(p)
        tn += newins; tc += len(conf)
        seen, bad, kinds = analyze(q)
        reach += len(seen); tb.update(bad); tk.update(kinds)
        if conf and shown < 3:
            shown += 1; print('conflict sample proto', pid, conf[:2])
    print('new instrs from patches', tn, 'conflicts', tc, 'reachable', reach)
    print('kinds', dict(tk)); print('bad', dict(tb))
