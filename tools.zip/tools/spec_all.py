exec(open('extract_ops.py').read().split("visit(rest, ALL)")[0])
import re, sys
JK = re.compile(r'T1\[1\]')
def spec_all(stmts, v, ind=0, out=None):
    out = [] if out is None else out
    pad = '  ' * ind
    for s in stmts:
        t = s['type']
        if t == 'AstStatIf':
            node = s; c = frozenset([v]); chain = []
            while node is not None and node['type'] == 'AstStatIf':
                tt, ff = cond(node['condition'])
                chain.append((node, tt, ff)); node = node.get('elsebody')
            final = node
            poss_else = True
            for (n, tt, ff) in chain:
                can_t, can_f = v in tt, v in ff
                if can_t and not can_f:
                    spec_all(n['thenbody']['body'], v, ind, out); poss_else = False; break
                if can_f and not can_t: continue
                # undetermined: walk both with marker
                sub = []; spec_all(n['thenbody']['body'], v, ind + 1, sub)
                if sub:
                    out.append(pad + 'IF? ' + ex(n['condition'])[:60]); out += sub
            if poss_else and final is not None:
                sub = []; spec_all(final['body'] if final['type'] == 'AstStatBlock' else [final], v, ind + 1, sub)
                if sub: out.append(pad + 'ELSE?'); out += sub
        elif t in ('AstStatWhile', 'AstStatRepeat', 'AstStatFor', 'AstStatForIn'):
            sub = []; spec_all(s['body']['body'], v, ind + 1, sub)
            if sub: out.append(pad + 'LOOP'); out += sub
        elif t == 'AstStatBlock': spec_all(s['body'], v, ind, out)
        else:
            txt = st(s).replace('\n', ' ')
            if JK.search(txt) and t in ('AstStatAssign', 'AstStatCompoundAssign', 'AstStatReturn'): continue
            out.append(pad + txt[:150])
    return out
for v in map(int, sys.argv[1:]):
    print('=== OP', v)
    for l in spec_all(rest, v): print(l)
