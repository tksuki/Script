import sys
sys.path.insert(0,'.')
from lift import *
pid = int(sys.argv[1])
protos = load(); p = protos[pid]
def lv(v):
    if v is None: return 'nil'
    if v is True: return 'true'
    if v is False: return 'false'
    if isinstance(v, tuple):
        if v[0] == 'S': return '"' + ''.join('\\%03d' % b for b in v[1]) + '"'
        return 'nil'
    if isinstance(v, float):
        if v != v: return '(0/0)'
        if v in (float('inf'), float('-inf')): return 'math.huge' if v > 0 else '-math.huge'
        return repr(v)
    return str(v)
n = max(p['ins'])
def arr(field):
    items = []
    for pc in range(1, n + 1):
        i = p['ins'].get(pc)
        if i is not None and i[field] is not None: items.append('[%d]=%s' % (pc, lv(i[field])))
    return '{' + ','.join(items) + '}'
ups = ','.join('{[2]=%d,[3]=%d}' % (a, b) for a, b in p['ups'])
lua = 'local PH = {[1]={%s},[2]=%s,[3]=%d,[4]=%s,[5]=%s,[7]=%s,[8]=%s,[9]=%s,[11]=%s}\n' % (
    ups, arr('p'), p['regs'], arr('o'), arr('op'), arr('g'), arr('C'), arr('G'), arr('a'))
open('proto_literal.lua', 'w').write(lua)
print('written', len(lua))
