import json, re, sys, collections
sys.setrecursionlimit(100000)
src = open('astprint.py').read().split("out = '\\n'.join(st(s) for s in d['body'])")[0]
ns = {}
exec(src, ns)
st, ex, lname, d = ns['st'], ns['ex'], ns['lname'], ns['d']

# ---- locate dispatcher ----
def walk(n, f, path=()):
    if isinstance(n, dict):
        if f(n, path): return True
        for k, v in n.items():
            if walk(v, f, path + ((n, k),)): return True
    elif isinstance(n, list):
        for i, v in enumerate(n):
            if walk(v, f, path + ((n, i),)): return True
    return False

found = {}
def finder(n, path):
    if n.get('type') == 'AstStatLocal' and len(n['vars']) == 1 and n['vars'][0]['name'] == 'i' and n['values']:
        v = n['values'][0]
        if v['type'] == 'AstExprIndexExpr' and v['expr']['type'] == 'AstExprLocal' and v['expr']['local']['name'] == '_' \
           and v['index']['type'] == 'AstExprLocal' and v['index']['local']['name'] == 'Q':
            found['stmt'] = n; found['path'] = path
            return True
walk(d, finder)
stmt = found['stmt']
# the repeat body block containing stmt
blocks = [p for p in found['path'] if isinstance(p[0], dict) and p[0].get('type') == 'AstStatBlock']
body_block = blocks[-1][0]
idx = body_block['body'].index(stmt)
rest = body_block['body'][idx+1:]
opvar = stmt['vars'][0]                      # AstLocal of opcode
opkey = (opvar['name'], opvar['location'])
print('dispatcher body statements after opcode fetch:', len(rest))

ALL = frozenset(range(0, 256))
def is_op(e):
    return e['type'] == 'AstExprLocal' and (e['local']['name'], e['local']['location']) == opkey
def const(e):
    if e['type'] == 'AstExprConstantNumber': return e['value']
    return None
def cmp_sets(op, c):
    r = range(0, 256)
    f = {'CompareEq': lambda x: x == c, 'CompareNe': lambda x: x != c, 'CompareLt': lambda x: x < c,
         'CompareLe': lambda x: x <= c, 'CompareGt': lambda x: x > c, 'CompareGe': lambda x: x >= c}[op]
    t = frozenset(x for x in r if f(x)); return t, ALL - t
FLIP = {'CompareLt':'CompareGt','CompareGt':'CompareLt','CompareLe':'CompareGe','CompareGe':'CompareLe','CompareEq':'CompareEq','CompareNe':'CompareNe'}
def cond(e):
    t = e['type']
    if t == 'AstExprGroup': return cond(e['expr'])
    if t == 'AstExprUnary' and e['op'] == 'Not':
        a, b = cond(e['expr']); return b, a
    if t == 'AstExprBinary':
        o = e['op']
        if o in FLIP:
            if is_op(e['left']) and const(e['right']) is not None: return cmp_sets(o, const(e['right']))
            if is_op(e['right']) and const(e['left']) is not None: return cmp_sets(FLIP[o], const(e['left']))
        if o == 'And':
            (tl, fl), (tr, fr) = cond(e['left']), cond(e['right']); return tl & tr, fl | fr
        if o == 'Or':
            (tl, fl), (tr, fr) = cond(e['left']), cond(e['right']); return tl | tr, fl & fr
    return ALL, ALL

# real variable identification: AstLocals declared in the instantiator prologue + x3 body prologue
real = set()
def collect_locals(n, acc):
    if isinstance(n, dict):
        if n.get('type') == 'AstLocal': acc.add((n['name'], n['location']))
        for v in n.values(): collect_locals(v, acc)
    elif isinstance(n, list):
        for v in n: collect_locals(v, acc)
# find the function node enclosing dispatcher: walk up path for AstExprFunction nodes
funcs = [p[0] for p in found['path'] if isinstance(p[0], dict) and p[0].get('type') == 'AstExprFunction']
print('enclosing function depth', len(funcs))
x3fn, inst = funcs[-2], funcs[-3] if len(funcs) >= 3 else None
# registers etc: locals declared at top-level of x3 body and instantiator body (not nested deeper)
for fn in (x3fn, inst):
    if fn is None: continue
    for a in fn['args']: real.add((a['name'], a['location']))
    for s in fn['body']['body']:
        if s['type'] == 'AstStatLocal':
            for v in s['vars']: real.add((v['name'], v['location']))
real_names = collections.Counter(n for n, _ in real)
def mentions_real(n):
    hit = [False]
    def f(m):
        if isinstance(m, dict):
            if m.get('type') == 'AstExprLocal' and (m['local']['name'], m['local']['location']) in real and not is_op(m) and m['local']['name'] not in ('x','T'): hit[0] = True
            for v in m.values(): f(v)
        elif isinstance(m, list):
            for v in m: f(v)
    f(n); return hit[0]

leaves = []   # (opset, text)
def visit(stmts, cur):
    for s in stmts:
        t = s['type']
        if t == 'AstStatIf':
            node = s; c = cur
            while node is not None and node['type'] == 'AstStatIf':
                tt, ff = cond(node['condition'])
                visit(node['thenbody']['body'], c & tt)
                c = c & ff
                node = node.get('elsebody')
            if node is not None:
                visit(node['body'], c)
        elif t in ('AstStatWhile', 'AstStatRepeat'):
            visit(s['body']['body'], cur)
        elif t in ('AstStatFor', 'AstStatForIn'):
            visit(s['body']['body'], cur)
        elif t == 'AstStatBlock':
            visit(s['body'], cur)
        else:
            if cur and mentions_real(s) and t in ('AstStatAssign','AstStatLocal','AstStatExpr','AstStatReturn','AstStatCompoundAssign'):
                leaves.append((cur, st(s)))
visit(rest, ALL)
print('leaf statements touching VM state:', len(leaves))
by_op = collections.defaultdict(list)
for opset, text in leaves:
    if len(opset) < 120:
        for v in opset: by_op[v].append(text)
json.dump({str(k): v for k, v in by_op.items()}, open('ops_raw.json', 'w'), indent=1)
for v in sorted(by_op)[:12]:
    print('--- opcode', v); 
    for t in by_op[v][:6]: print('   ', t[:200].replace('\n',' '))
print('opcodes with candidates:', len(by_op))
