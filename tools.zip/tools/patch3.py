from patch2 import *
import copy
NIL = ('NIL',)

def ev(e, val):
    t = e[0]
    if t == 'K':
        v = e[1]
        if v is None: return NIL
        if isinstance(v, bool): return v
        return v
    if t == 'R': return val.get(e[1])
    if t == 'POOL': return math.pi if e[1] == 10 else ('FN', POOLN.get(e[1], '?'))
    if t == 'BIN':
        a, b = ev(e[2], val), ev(e[3], val)
        if a is None or b is None: return None
        op = e[1]
        isnum = lambda x: isinstance(x, (int, float)) and not isinstance(x, bool)
        try:
            if op in ('+', '-', '*', '/', '%', '^'):
                if not (isnum(a) and isnum(b)): return None
                if op == '+': return a + b
                if op == '-': return a - b
                if op == '*': return a * b
                if op == '/': return a / b
                if op == '%': return a - math.floor(a / b) * b
                return a ** b
            if op in ('<', '<=', '>', '>='):
                if isnum(a) and isnum(b): return {'<': a < b, '<=': a <= b, '>': a > b, '>=': a >= b}[op]
                return None
            if op in ('==', '~='):
                if (isnum(a) or isinstance(a, bool) or a == NIL or isinstance(a, tuple)) and (isnum(b) or isinstance(b, bool) or b == NIL or isinstance(b, tuple)):
                    r = (a == b) if not (isnum(a) != isnum(b)) else False
                    return r if op == '==' else (not r)
                return None
            if op == '..':
                if isinstance(a, tuple) and a[0] == 'S' and isinstance(b, tuple) and b[0] == 'S': return ('S', a[1] + b[1])
                return None
        except Exception: return None
        return None
    if t == 'UN':
        a = ev(e[2], val)
        if a is None: return None
        if e[1] == 'not': return not (a is not False and a != NIL)
        if e[1] == '-' and isinstance(a, (int, float)) and not isinstance(a, bool): return -a
        return None
    return None

def truthy(v):
    if v is None: return None
    return not (v is False or v == NIL)

def simulate(p):
    view = copy.deepcopy(p['ins'])
    patches = {}; writers = set(); unresolved = []
    visited = set()
    decided = {}
    stack = [(1, {}, {})]
    steps = 0
    while stack and steps < 400000:
        pc, val, arrs = stack.pop()
        while True:
            steps += 1
            if pc in visited or pc not in view: break
            visited.add(pc)
            ins = view[pc]; op = ins['op']
            if op == 92 and ins['G'] is not None: arrs[ins['G']] = 'g'; pc += 1; continue
            if op == 87 and ins['o'] is not None: arrs[ins['o']] = 'G'; pc += 1; continue
            if op == 142 and ins['G'] is not None: arrs[ins['G']] = 'o'; pc += 1; continue
            if op == 83 and ins['g'] is not None: arrs[ins['g']] = '_'; pc += 1; continue
            if op == 139 and ins['G'] is not None: arrs[ins['G']] = 'R'; pc += 1; continue
            if op == 41 and ins['g'] is not None: arrs[ins['g']] = 'H'; pc += 1; continue
            if op == 143 and ins['g'] in arrs: arrs.pop(ins['g']); val.pop(ins['g'], None); pc += 1; continue
            if op in (69, 81, 131, 39):
                if op == 69: treg, key, v = ins['o'], ins['p'], ins['a']
                elif op == 81: treg, key, v = ins['g'], ins['C'], val.get(ins['G'])
                elif op == 131: treg, key, v = ins['G'], val.get(ins['o']), val.get(ins['g'])
                else: treg, key, v = ins['G'], val.get(ins['o']), ins['a']
                if treg in arrs:
                    kind = arrs[treg]
                    okn = lambda x: isinstance(x, (int, float)) and not isinstance(x, bool)
                    if okn(key) and okn(v):
                        if isinstance(v, float) and v == int(v): v = int(v)
                        if isinstance(key, float) and key == int(key): key = int(key)
                        patches[(kind, key)] = v; writers.add(pc)
                        if kind in ('g', 'G', 'o', '_'):
                            if key not in view: view[key] = dict(op=None, g=None, G=None, o=None, C=None, a=None, p=None)
                            view[key]['op' if kind == '_' else kind] = v
                    else:
                        unresolved.append((pc, op, kind, key, v)); writers.add(pc)
                    pc += 1; continue
            try: d = decode(ins)
            except Exception: d = ('bad',)
            k = d[0]
            # register effects
            defs = []
            if k == 'set' and isinstance(d[1], int):
                r = ev(d[2], val)
                for rr in [d[1]]: arrs.pop(rr, None)
                if r is None: val.pop(d[1], None)
                else: val[d[1]] = r
            elif k == 'call' and isinstance(d[1], int):
                A, B, C = d[1], d[2], d[3]
                fn = val.get(A); res = None
                if isinstance(fn, tuple) and fn[0] == 'FN' and isinstance(B, int) and B > 0 and C == 2:
                    res = callpool(fn[1], [val.get(A + i) for i in range(1, B)])
                n = max((C - 1) if isinstance(C, int) else 1, 1)
                for rr in range(A, A + n): arrs.pop(rr, None); val.pop(rr, None)
                if res is not None: val[A] = res
            elif k == 'self' and isinstance(d[1], int):
                for rr in (d[1], d[1] + 1): arrs.pop(rr, None); val.pop(rr, None)
            elif k in ('closure',) and isinstance(d[1], int): arrs.pop(d[1], None); val.pop(d[1], None)
            elif k == 'loadnil' and isinstance(d[1], int) and isinstance(d[2], int):
                for rr in range(d[1], d[2] + 1): arrs.pop(rr, None); val[rr] = NIL
            elif k == 'vararg' and isinstance(d[1], int): arrs.pop(d[1], None); val.pop(d[1], None)
            elif k == 'params' and isinstance(d[1], int):
                for rr in range(1, d[1] + 1): arrs.pop(rr, None); val.pop(rr, None)
            elif k in ('tforloop',) and isinstance(d[1], int):
                for rr in (d[1] + 1, d[1] + 2): arrs.pop(rr, None); val.pop(rr, None)
            elif k == 'forloop' and isinstance(d[1], int): arrs.pop(d[1] + 3, None); val.pop(d[1] + 3, None)
            # control flow
            if k == 'jump':
                if not isinstance(d[1], int): break
                pc = d[1] + 1; continue
            if k == 'cjump':
                if not isinstance(d[2], int): break
                c = truthy(ev(d[1], val)) if True else None
                decided.setdefault(pc, set()).add(c)
                tgt = d[2] + 1
                if c is True: pc = tgt; continue
                if c is False: pc += 1; continue
                stack.append((tgt, dict(val), dict(arrs))); pc += 1; continue
            if k in ('forprep', 'tforprep'):
                if not isinstance(d[2], int): break
                pc = d[2] + 1; continue
            if k in ('forloop', 'tforloop'):
                if not isinstance(d[2], int): break
                stack.append((d[2] + 1, dict(val), dict(arrs))); pc += 1; continue
            if k in ('ret', 'tail', 'bad'): break
            pc += 1
    return view, patches, writers, unresolved, visited, decided

def apply_patches3(p):
    view, patches, writers, unres, visited, decided = simulate(p)
    q = copy.deepcopy(p); q['ins'] = view
    q['decided'] = decided
    return q, writers, [], unres, visited

if __name__ == '__main__':
    protos = load()
    tu = 0; tw = 0; unv = 0; totv = 0; badops = 0
    for pid, p in protos.items():
        q, w, c, u, vis = apply_patches3(p)
        tu += len(u); tw += len(w); totv += len(vis)
        for pc in vis:
            ins = q['ins'][pc]
            try: d = decode(ins)
            except Exception: d = ('bad',)
            if d[0] in ('bad', 'unknown'): badops += 1
    print('writers', tw, 'unresolved', tu, 'visited', totv, 'bad/unknown ops among visited', badops)
