from dec5 import *

# ---------------------------------------------------------------- (a) duplicate small terminal blocks instead of goto
def small_terminal(self, L):
    total = 0; cur = L; seen = set()
    while cur is not None and cur not in seen:
        seen.add(cur)
        b = self.blocks.get(cur)
        if b is None: return False
        total += len([n for n in self.nodes[cur] if not n.dead])
        if total > 40: return False
        if b.kind == 'ret': return True
        if b.kind == 'goto': cur = b.succ[0]; continue
        return False
    return False
Emitter.small_terminal = small_terminal

_old_gen = Emitter.gen
def gen2(self, L, stops, ctx, first=False):
    # intercept the visited case
    out = []
    if (not first) and L is not None and L in self.visited and not (ctx and (L == ctx['cont'] or L == ctx['break'])) and L not in stops and self.small_terminal(L) and L not in self.loops:
        cur = L
        while True:
            out += self.block_stmts(cur)
            b = self.blocks[cur]
            if b.kind == 'ret': return out
            cur = b.succ[0]
    return _old_gen(self, L, stops, ctx, first)
# gen2 disabled (handled in dec5)

# ---------------------------------------------------------------- (b)(d) AST cleanups
STR = re.compile(r'"(?:[^"\\]|\\.)*"')
def idempotent(t):
    u = STR.sub('""', t)
    if 'function' in u: return False
    if t.startswith('table.move('): return True
    return '(' not in u
def dedupe(ast):
    i = 0
    while i < len(ast):
        done = False
        for k in range(1, 9):
            if i + 2 * k <= len(ast):
                a, b = ast[i:i + k], ast[i + k:i + 2 * k]
                if all(x[0] == 's' for x in a + b) and a == b and all(idempotent(x[1]) for x in a):
                    del ast[i + k:i + 2 * k]; done = True; break
        if not done: i += 1
    return ast
ASG = re.compile(r'^(local )?([A-Za-z_]\w*) = (.*)$', re.S)
def wrap_and(s): return '(' + s + ')' if ' or ' in s and not (s.startswith('(') and s.endswith(')')) else s
def andor(ast):
    i = 0
    while i < len(ast) - 1:
        n = ast[i]; m = ast[i + 1]
        if n[0] == 's' and m[0] == 'if' and m[3] is None and len(m[2]) == 1 and m[2][0][0] == 's':
            ma = ASG.match(n[1]); mb = ASG.match(m[2][0][1])
            if ma and mb and mb.group(1) is None and ma.group(2) == mb.group(2) and '\n' not in n[1]:
                name = ma.group(2)
                if m[1] == name:
                    ast[i:i + 2] = [('s', '%s%s = %s and %s' % (ma.group(1) or '', name, wrap_and(ma.group(3)), wrap_and(mb.group(3))))]
                    continue
                if m[1] == 'not ' + name:
                    ast[i:i + 2] = [('s', '%s%s = %s or %s' % (ma.group(1) or '', name, ma.group(3), mb.group(3) if ' and ' not in mb.group(3) or True else mb.group(3)))]
                    continue
        i += 1
    return ast
def gotoor(ast):
    i = 0
    while i < len(ast) - 3:
        a, b, c, d = ast[i:i + 4]
        if a[0] == 's' and b[0] == 'if' and b[3] is None and len(b[2]) == 1 and b[2][0][0] == 'goto' and c[0] == 's' and d[0] == 'label' and b[2][0][1] == d[1]:
            ma = ASG.match(a[1]); mc = ASG.match(c[1])
            if ma and mc and mc.group(1) is None and ma.group(2) == mc.group(2) and b[1] == ma.group(2):
                ast[i:i + 4] = [('s', '%s%s = %s or %s' % (ma.group(1) or '', ma.group(2), ma.group(3), mc.group(3)))]
                continue
        i += 1
    return ast
def cleanup(ast):
    for n in ast:
        if n[0] == 'if':
            cleanup(n[2])
            if n[3] is not None: cleanup(n[3])
        elif n[0] in ('while', 'for'): cleanup(n[2])
    gotoor(ast); andor(ast); dedupe(ast); andor(ast)
    return ast

_old_run = Emitter.run
def run2(self, final):
    ast = _old_run(self, final)
    return cleanup(ast)
Emitter.run = run2

# ---------------------------------------------------------------- (c) generic-for with nil state/control
_old_inline = inline_pass
def tfor_fix(self_nodes, webs):
    pass

# ---------------------------------------------------------------- (e) naming heuristics
LUAKEYS = LUAKW | set(['self'])
def sugg(e):
    def sname(x):
        return x[1][1].decode('latin-1') if x[0] == 'K' and isinstance(x[1], tuple) and x[1][0] == 'S' else None
    t = e[0]
    if t == 'CALL':
        f, args = e[1], e[2]
        if f[0] == 'SELFFN':
            key = sname(f[2])
            if key in ('GetService', 'WaitForChild', 'FindFirstChild', 'FindFirstChildOfClass', 'FindFirstAncestor', 'FindFirstChildWhichIsA', 'FindFirstDescendant') and len(args) >= 2:
                return sname(args[1])
            if key == 'Clone': return 'clone'
            if key == 'GetChildren': return 'children'
            if key == 'GetDescendants': return 'descendants'
            if key == 'GetPlayers': return 'players'
            if key == 'Connect': return 'connection'
        if f[0] == 'IDX' and f[1][0] == 'ENV' and sname(f[1][1]) == 'Instance' and sname(f[2]) == 'new' and args:
            n = sname(args[0]); return n[:1].lower() + n[1:] if n else None
        if f[0] == 'ENV' and sname(f[1]) in ('Instance',): return None
        if f[0] == 'ENV':
            fn = sname(f[1]) or ''
            if fn == 'pcall': return 'ok'
            if fn == 'tostring': return 'str'
            if fn == 'tonumber': return 'num'
            if fn == 'type' or fn == 'typeof': return 'ty'
            return None
    if t == 'IDX':
        k = sname(e[2])
        if k: return k
    if t == 'ENV': return sname(e[1])
    if t == 'TABLE': return 'tbl'
    if t == 'FUNC': return 'fn'
    return None
def clean_ident(s):
    if not s: return None
    s = re.sub(r'[^A-Za-z0-9_]', '_', s)
    if not s or s[0].isdigit(): s = '_' + s
    return s[:24]
GLOBALS_SEEN = set()
def collect_globals(protos):
    for p in protos.values():
        for i in p['ins'].values():
            if i['op'] in (52, 53, 107):
                v = i['a'] if i['op'] in (52, 53) else i['p']
                if isinstance(v, tuple) and v[0] == 'S': GLOBALS_SEEN.add(v[1].decode('latin-1'))
def webname2(self, root):
    w = self.webs[root]
    if w.name is None:
        pn = None; first = None
        for (sid, r) in sorted(w.defs):
            dn = self.defnode.get((sid, r))
            if dn is not None:
                if dn.k == 'params': pn = r
                if first is None: first = dn
        if pn is not None:
            self.counter += 1; w.name = 'arg%d' % pn if self.depth == 0 else 'p%d_%d' % (self.depth, pn)
            if self.depth > 0: w.name = 'a%d_%d' % (self.depth, pn)
        else:
            base = None
            if first is not None and first.k == 'assign' and first.e is not None:
                base = clean_ident(sugg(first.e))
            if base is None or base in LUAKEYS or base in GLOBALS_SEEN: base = ('v' if base is None else base + '_')
            avoid = self.avoid
            name = base; n = 1
            if base == 'v':
                self.counter += 1; name = 'v%d' % self.counter
                while name in self.used or name in avoid: self.counter += 1; name = 'v%d' % self.counter
            else:
                while name in self.used or name in avoid: n += 1; name = '%s%d' % (base, n)
            self.used.add(name); w.name = name
    return w.name
Emitter.webname = webname2

_old_init = Emitter.__init__
def init2(self, protos, pid, upnames, depth=0):
    self.avoid = set(n for n in upnames if n)
    self.used = set()
    _old_init(self, protos, pid, upnames, depth)
Emitter.__init__ = init2
_old_run2 = Emitter.run
def run3(self, final):
    self.used = set()
    return _old_run2(self, final)
Emitter.run = run3



# ---------------------------------------------------------------- short-circuit condition merging
def merge_conditions(self):
    blocks = self.blocks
    def condnode(L):
        ns = [n for n in self.nodes[L] if not n.dead]
        return ns
    changed = True
    while changed:
        changed = False
        for L in list(blocks):
            b = blocks.get(L)
            if b is None or b.kind != 'cjump' or len(b.succ) != 2 or None in b.succ: continue
            n1 = condnode(L)
            if not n1 or n1[-1].k != 'cond': continue
            for idx in (1, 0):        # 1: fallthrough is B2 ; 0: taken is B2
                B2 = b.succ[idx]
                if B2 == L or B2 not in blocks: continue
                b2 = blocks[B2]
                if b2.kind != 'cjump' or len(b2.succ) != 2 or None in b2.succ or len(b2.preds) != 1: continue
                n2 = condnode(B2)
                if len(n2) != 1 or n2[0].k != 'cond': continue
                other = b.succ[1 - idx]
                T2, F2 = b2.succ
                c1 = n1[-1].e; c2 = n2[0].e
                if idx == 1:      # c1 false -> evaluate c2.   b: taken=other (c1 true), fall=B2
                    if other == T2:      # (c1 or c2) -> other ; else F2
                        e = ('BIN', 'or', c1, c2); b.succ = [other, F2]
                    elif other == F2:    # c1 true -> other; c1 false & c2 false -> other; c2 true -> T2
                        e = ('BIN', 'and', self.negate(c1), c2); b.succ = [T2, other]
                    else: continue
                else:             # c1 true -> evaluate c2.  b: taken=B2, fall=other
                    if other == F2:      # (c1 and c2) -> T2 ; else other
                        e = ('BIN', 'and', c1, c2); b.succ = [T2, other]
                    elif other == T2:    # c1 true & c2 true -> other ; c1 true & c2 false -> F2 ; c1 false -> other
                        e = ('BIN', 'or', self.negate(c1), self.negate(c2)); b.succ = [F2, other]
                    else: continue
                n1[-1].e = e
                n2[0].dead = True
                del blocks[B2]; del self.nodes[B2]
                changed = True
                break
    # recompute preds
    for L, bb in blocks.items(): bb.preds = []
    for L, bb in blocks.items():
        for s in bb.succ:
            if s is not None and s in blocks: blocks[s].preds.append(L)
_old_cg = Emitter.compute_graph
def cg2(self):
    merge_conditions(self)
    _old_cg(self)
Emitter.compute_graph = cg2

# ---------------------------------------------------------------- condition simplification
NEGCMP = {'<': '>=', '<=': '>', '>': '<=', '>=': '<', '==': '~=', '~=': '=='}
def neg(e):
    if e[0] == 'UN' and e[1] == 'not': return e[2]
    if e[0] == 'BIN':
        if e[1] in NEGCMP: return ('BIN', NEGCMP[e[1]], e[2], e[3])
        if e[1] == 'and': return ('BIN', 'or', neg(e[2]), neg(e[3]))
        if e[1] == 'or': return ('BIN', 'and', neg(e[2]), neg(e[3]))
    if e[0] == 'K' and isinstance(e[1], bool): return ('K', not e[1])
    return ('UN', 'not', e)
def simp(e):
    if e[0] == 'UN' and e[1] == 'not':
        inner = e[2]
        if inner[0] == 'BIN' and inner[1] in list(NEGCMP) + ['and', 'or'] or (inner[0] == 'UN' and inner[1] == 'not'):
            return simp(neg(inner))
        return ('UN', 'not', simp(inner))
    if e[0] == 'BIN' and e[1] in ('and', 'or'):
        return ('BIN', e[1], simp(e[2]), simp(e[3]))
    return e
Emitter.negate = lambda self, e: simp(neg(e))
_old_ex = Emitter.ex
def ex2(self, e, prec=0):
    if e[0] == 'UN' and e[1] == 'not':
        s = simp(e)
        if s != e: return _old_ex(self, s, prec)
    return _old_ex(self, e, prec)
Emitter.ex = ex2

if __name__ == '__main__':
    protos = load(); collect_globals(protos)
    em = Emitter(protos, int(sys.argv[1]), [], depth=0)
    print(em.render_function())
