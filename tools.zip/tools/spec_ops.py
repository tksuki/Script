exec(open('extract_ops.py').read().split("visit(rest, ALL)")[0])
import re
def real_cond(e):
    return mentions_real(e)
def has_real(stmts):
    return any(mentions_real(s) and s['type'] in ('AstStatAssign','AstStatLocal','AstStatExpr','AstStatReturn','AstStatCompoundAssign') or
               (s['type']=='AstStatIf' and (real_cond(s['condition']) or has_real(s['thenbody']['body']) or (s.get('elsebody') and has_real_node(s['elsebody']))))
               or (s['type'] in ('AstStatWhile','AstStatRepeat','AstStatFor','AstStatForIn') and has_real(s['body']['body']))
               or (s['type']=='AstStatBlock' and has_real(s['body'])) for s in stmts)
def has_real_node(n):
    return has_real(n['body']) if n['type']=='AstStatBlock' else has_real([n])
JUNKRE = re.compile(r'^\(?T1\[1\]\)?\[\d+\]')
def spec(stmts, v, ind=0):
    out=[]
    pad='  '*ind
    for s in stmts:
        t=s['type']
        if t=='AstStatIf':
            node=s; branches=[]; chain=[]
            # evaluate chain
            cur=True; live=[]
            n=node
            conds=[]
            while n is not None and n['type']=='AstStatIf':
                tt,ff=cond(n['condition'])
                conds.append((n,tt,ff)); n=n.get('elsebody')
            final_else=n
            # walk chain: skip branches impossible for v
            res=[]; possible_else=True
            for (n,tt,ff) in conds:
                can_t = v in tt; can_f = v in ff
                c=n['condition']
                if not can_t and not can_f: continue
                if can_t and not can_f:
                    res.append(('T',n,None)); possible_else=False; break
                if can_f and not can_t:
                    continue
                # undetermined by i: real or opaque condition
                res.append(('?',n,c))
            else:
                pass
            # build output
            if possible_else and final_else is not None and not (res and res[-1][0]=='T'):
                res.append(('E',final_else,None))
            first=True
            for kind,n,c in res:
                if kind=='T':
                    body=spec(n['thenbody']['body'],v,ind if first and len(res)==1 else ind+1)
                    if first and len(res)==1: out+=body
                    else:
                        out.append(pad+('if true then' if first else 'elseif true then')); out+=body
                elif kind=='?':
                    body=spec(n['thenbody']['body'],v,ind+1)
                    if real_cond(c):
                        out.append(pad+('if ' if first else 'elseif ')+ex(c)+' then'); out+=body; first=False
                    else:
                        # opaque: include only if real content
                        if body: out.append(pad+'-- [opaque-then]'); out+=body
                elif kind=='E':
                    body=spec(final_else['body'] if final_else['type']=='AstStatBlock' else [final_else],v,ind+1)
                    if body:
                        if not first: out.append(pad+'else')
                        else: out.append(pad+'-- [opaque-else]')
                        out+=body
            if not first and any(k in('?',) and real_cond(c) for k,n,c in res): out.append(pad+'end')
        elif t in ('AstStatWhile','AstStatRepeat','AstStatFor','AstStatForIn'):
            body=spec(s['body']['body'],v,ind+1)
            if body:
                hdr = 'while ... do' if t=='AstStatWhile' else ('repeat' if t=='AstStatRepeat' else ('for ... do' if t=='AstStatFor' else 'for ... in ... do'))
                out.append(pad+hdr); out+=body; out.append(pad+('until ...' if t=='AstStatRepeat' else 'end'))
        elif t=='AstStatBlock':
            out+=spec(s['body'],v,ind)
        else:
            if mentions_real(s) and t in ('AstStatAssign','AstStatLocal','AstStatExpr','AstStatReturn','AstStatCompoundAssign'):
                txt=st(s)
                if t=='AstStatAssign' and JUNKRE.match(txt): continue
                if t=='AstStatReturn' and 'T1[1]' in txt and 'T1[1][4' in txt and False: continue
                out.append(pad+txt.replace('\n',' '))
    return out
res={}
for v in range(0,150):
    lines=spec(rest,v)
    # drop pure-junk lines (touch only T1 state)
    lines=[l for l in lines if not re.match(r'^\s*\(?T1\[1\]\)?\[',l) and not re.match(r'^\s*return T1',l)]
    res[v]=lines
open('ops_spec.txt','w').write('\n'.join('== %d\n%s'%(v,'\n'.join(l)) for v,l in res.items()))
for v in range(0,40):
    print('== %d'%v); print('\n'.join(res[v][:14]))
