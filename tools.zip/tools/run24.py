import sys, time, traceback
sys.path.insert(0, '.')
sys.setrecursionlimit(50000)
import threading
threading.stack_size(512*1024*1024)
from dec6 import *
def main():
    protos = load(); collect_globals(protos)
    pid = int(sys.argv[1])
    t = time.time()
    try:
        em = Emitter(protos, pid, [], depth=0)
        txt = em.render_function()
        open('out_p%d.lua' % pid, 'w').write(txt)
        print('OK', pid, len(txt), 'chars', txt.count('\n'), 'lines', round(time.time() - t, 1), 's')
    except Exception as e:
        traceback.print_exc(limit=-3)
        print('FAIL', pid, round(time.time() - t, 1))
th = threading.Thread(target=main); th.start(); th.join()
