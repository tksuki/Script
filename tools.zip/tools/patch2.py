from lift import *
import copy, math, operator


import re as _re
def packsize(fmt):
    sizes = {'b':1,'B':1,'h':2,'H':2,'i':4,'I':4,'l':8,'L':8,'j':4,'J':4,'T':4,'f':4,'d':8,'n':8,'x':1}
    tot = 0; i = 0; f = fmt.decode('latin-1')
    while i < len(f):
        c = f[i]; i += 1
        if c in ' <>=': continue
        if c == '!':
            while i < len(f) and f[i].isdigit(): i += 1
            continue
        n = ''
        while i < len(f) and f[i].isdigit(): n += f[i]; i += 1
        if c in 'iI': tot += int(n) if n else 4
        elif c == 'c': tot += int(n) if n else 0
        elif c in sizes: tot += sizes[c]
        else: return None
    return tot
def b32(op, args):
    try:
        a = [int(x) & 0xFFFFFFFF for x in args if isinstance(x, (int, float))]
        if op == 'bxor': r = 0; [r := r ^ x for x in a]; return r
        if op == 'band': r = 0xFFFFFFFF; [r := r & x for x in a]; return r
        if op == 'bor': r = 0; [r := r | x for x in a]; return r
        if op == 'bnot': return (~a[0]) & 0xFFFFFFFF
        if op in ('rrotate', 'lrotate'):
            n = int(args[1]) % 32
            if op == 'lrotate': n = (32 - n) % 32
            return ((a[0] >> n) | (a[0] << (32 - n))) & 0xFFFFFFFF if n else a[0]
        if op == 'countlz': return 32 - a[0].bit_length()
        if op == 'countrz': return 32 if a[0] == 0 else (a[0] & -a[0]).bit_length() - 1
        if op == 'lshift': return (a[0] << (int(args[1]) & 255)) & 0xFFFFFFFF if int(args[1]) < 32 else 0
        if op == 'rshift': return (a[0] >> int(args[1])) if int(args[1]) < 32 else 0
    except Exception: return None
def callpool(name, args):
    need = {'string.packsize':1,'string.len':1,'string.byte':2,'math.floor':1,'math.ceil':1,'string.unpack':2}.get(name)
    if need is not None:
        if len(args) < need or any(x is None for x in args[:need]): return None
    elif any(x is None for x in args): return None
    if name == 'string.packsize' and isinstance(args[0], tuple) and args[0][0] == 'S': return packsize(args[0][1])
    if name == 'string.len' and isinstance(args[0], tuple) and args[0][0] == 'S': return len(args[0][1])
    if name == 'string.byte' and isinstance(args[0], tuple) and args[0][0] == 'S':
        i = int(args[1])
        b = args[0][1]
        return b[i - 1] if 1 <= i <= len(b) else None
    if name == 'string.unpack' and len(args) >= 2 and isinstance(args[0], tuple) and isinstance(args[1], tuple):
        import struct
        f = args[0][1].decode('latin-1'); b = args[1][1]
        try:
            end = '<' if '<' in f else ('>' if '>' in f else '<')
            m = _re.search(r'([iI])(\d*)', f)
            if m:
                n = int(m.group(2)) if m.group(2) else 4
                return int.from_bytes(b[:n], 'little' if end == '<' else 'big', signed=(m.group(1) == 'i'))
            if 'd' in f or 'n' in f: return struct.unpack(end + 'd', b[:8])[0]
            if 'f' in f: return struct.unpack(end + 'f', b[:4])[0]
        except Exception: return None
        return None
    if name == 'math.modf' and isinstance(args[0], (int, float)): return float(math.trunc(args[0]))
    if name == 'math.floor' and isinstance(args[0], (int, float)): return math.floor(args[0])
    if name == 'math.ceil' and isinstance(args[0], (int, float)): return math.ceil(args[0])
    if name.startswith('bit32.'): return b32(name[6:], args)
    return None
POOLN = {4:'?4',6:'string.packsize',7:'bit32.rrotate',8:'bit32.bnot',9:'math.ceil',11:'bit32.bor',12:'bit32.rshift',13:'math.floor',14:'string.len',15:'bit32.band',16:'string.byte',17:'string.unpack',18:'bit32.bxor',19:'bit32.lshift',20:'math.modf',21:'bit32.countlz',22:'bit32.countrz',23:'bit32.lrotate'}

def evalexpr(e, val):
    t = e[0]
    if t == 'K':
        v = e[1]
        if isinstance(v, tuple) and v[0] == 'S': return v
        return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None
    if t == 'R': return val.get(e[1])
    if t == 'POOL': return math.pi if e[1] == 10 else ('FN', POOLN.get(e[1], '?'))
    if t == 'BIN':
        a, b = evalexpr(e[2], val), evalexpr(e[3], val)
        if a is None or b is None or isinstance(a, tuple) or isinstance(b, tuple): return None
        op = e[1]
        try:
            if op == '+': return a + b
            if op == '-': return a - b
            if op == '*': return a * b
            if op == '/': return a / b
            if op == '%': return a - math.floor(a / b) * b
            if op == '^': return a ** b
        except Exception: return None
        return None
    if t == 'UN' and e[1] == '-':
        a = evalexpr(e[2], val); return None if a is None else -a
    return None

def collect_patches2(p, view=None):
    ins_all = view if view is not None else p['ins']
    arrs = {}; val = {}
    patches = collections.defaultdict(set); writers = set(); unresolved = []
    for pc in sorted(ins_all):
        ins = ins_all[pc]; op = ins['op']
        if op == 92 and ins['G'] is not None: arrs[ins['G']] = 'g'
        elif op == 87 and ins['o'] is not None: arrs[ins['o']] = 'G'
        elif op == 142 and ins['G'] is not None: arrs[ins['G']] = 'o'
        elif op == 83 and ins['g'] is not None: arrs[ins['g']] = '_'
        elif op == 139 and ins['G'] is not None: arrs[ins['G']] = 'R'
        elif op == 41 and ins['g'] is not None: arrs[ins['g']] = 'H'
        elif op == 143 and ins['g'] in arrs: arrs.pop(ins['g']); val.pop(ins['g'], None)
        elif op in (69, 81, 131, 39):
            if op == 69: treg, key, v = ins['o'], ins['p'], ins['a']
            elif op == 81: treg, key, v = ins['g'], ins['C'], val.get(ins['G'])
            elif op == 131: treg, key, v = ins['G'], val.get(ins['o']), val.get(ins['g'])
            else: treg, key, v = ins['G'], val.get(ins['o']), ins['a']
            if treg in arrs:
                kind = arrs[treg]
                if isinstance(key, (int, float)) and not isinstance(key, bool) and isinstance(v, (int, float)) and not isinstance(v, bool):
                    if isinstance(v, float) and v == int(v): v = int(v)
                    if isinstance(key, float) and key == int(key): key = int(key)
                    patches[(kind, key)].add(v); writers.add(pc)
                else: unresolved.append((pc, op, kind, key, v)); writers.add(pc)
            continue
        # constant propagation (linear order)
        try: d = decode(ins)
        except Exception: d = None
        if d is not None:
            defs = []
            if d[0] == 'set' and isinstance(d[1], int): defs = [d[1]]
            elif d[0] == 'call' and isinstance(d[1], int) and isinstance(d[3], int): defs = list(range(d[1], d[1] + max(d[3] - 1, 1)))
            elif d[0] == 'self' and isinstance(d[1], int): defs = [d[1], d[1] + 1]
            elif d[0] == 'closure' and isinstance(d[1], int): defs = [d[1]]
            elif d[0] == 'loadnil' and isinstance(d[1], int) and isinstance(d[2], int): defs = list(range(d[1], d[2] + 1))
            elif d[0] == 'vararg' and isinstance(d[1], int): defs = [d[1]]
            elif d[0] == 'params' and isinstance(d[1], int): defs = list(range(1, d[1] + 1))
            for r in defs:
                if arrs.get(r) is not None and not (d[0] == 'set' and ins['op'] == 143): arrs.pop(r, None)
        if d is not None and d[0] == 'set' and d[1] is not None:
            r = evalexpr(d[2], val)
            if r is None: val.pop(d[1], None)
            else: val[d[1]] = r
        elif d is not None and d[0] == 'call':
            A, B, C = d[1], d[2], d[3]
            if not isinstance(A, int): continue
            res = None
            fn = val.get(A)
            if isinstance(fn, tuple) and fn[0] == 'FN' and B is not None and B > 0 and C == 2:
                res = callpool(fn[1], [val.get(A + i) for i in range(1, B)])
            if res is None: val.pop(A, None)
            else: val[A] = res
        elif d is not None and d[0] in ('self', 'loadnil', 'vararg', 'closure'):
            if d[0] == 'self' and isinstance(d[1], int): val.pop(d[1], None); val.pop(d[1] + 1, None)
    return patches, writers, unresolved

def apply_patches2(p):
    q = copy.deepcopy(p); conflict = []
    allp = {}
    for it in range(6):
        pt, writers, unres = collect_patches2(p, q['ins'])
        changed = False
        for (kind, idx), vals in pt.items():
            if kind not in ('g', 'G', 'o', '_'): continue
            v = sorted(vals)[0]
            if allp.get((kind, idx)) != v:
                allp[(kind, idx)] = v; changed = True
            if len(vals) > 1: conflict.append((kind, idx, vals))
            if idx not in q['ins']: q['ins'][idx] = dict(op=None, g=None, G=None, o=None, C=None, a=None, p=None)
            q['ins'][idx]['op' if kind == '_' else kind] = v
        if not changed: break
    return q, writers, conflict, unres

if __name__ == '__main__':
    protos = load()
    tc = 0; tu = 0; tw = 0; ex = []
    for pid, p in protos.items():
        q, w, c, u = apply_patches2(p)
        tc += len(c); tu += len(u); tw += len(w)
        if c and len(ex) < 3: ex.append((pid, c[:2]))
        if u and len(ex) < 6: ex.append((pid, 'unres', u[:2]))
    print('writers', tw, 'conflicts', tc, 'unresolved', tu); print(ex)
